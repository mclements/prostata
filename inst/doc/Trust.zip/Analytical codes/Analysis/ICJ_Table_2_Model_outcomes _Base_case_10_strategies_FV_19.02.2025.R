#=======================================================================================================================
#FILENAME: EU manuscript:  Figure 2_CEA of PCa screening_Base case_FV
# PROJECT: Cost-effectiveness of prostate cancer screening strategies in Germany: a population-based microsimulation study
# PURPOSE: To generate Figures for the manuscript
# AUTHOR: Trust Muchadeyi adapted from Shuang Hao

# CREATED: 2023-06-19
# LAST UPDATED: 2024-05-01

## R version: R-4.3.1

# INPUT DATA: 
# NA 
# OUTPUT Data
# Output 1: "../Output_EU_submitted_version/Figure 2_CEA of PCa screening_Base case_FV_Submitted__FV.pdf"
#=======================================================================================================================
# Define a vector of package names
packages <- c("ggplot2", "dplyr", "tidyr", "ggrepel", "openxlsx", "prostata", 
              "scales", "grid","gridExtra", "gtable", "cowplot", "extrafont", "Cairo", "here")

# Loop through each package name
for (pkg in packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
  library(pkg, character.only = TRUE)
}

font_import()  # It might take some time as it scans your system for all fonts.
loadfonts(device = "win")  # For Windows bitmap output
loadfonts(device = "pdf")  # For PDF output
##=======================================================================================================================
load(file = "..\\Data\\PhD_Monogram_Base_case_strategies_1e+07_simulations_2024-12-07.Rdata")
##=======================================================================================================================

strategies = list(# Ten Base case strategies
                  strategies$strategy1,                                        # 1. PSA-Risk-adaptive : 45-60: No MRI
                  strategies$strategy2,                                        # 2. PSA-Risk-adaptive : 45-70: No MRI
                  strategies$strategy3,                                        # 3. PSA-Risk-adaptive : 50-60: No MRI
                  strategies$strategy4,                                        # 4. PSA-Risk-adaptive : 50-70: No MRI
                  strategies$strategy5,                                        # 5. PSA-Risk-adaptive : 45-60: With MRI
                  strategies$strategy6,                                        # 6. PSA-Risk-adaptive : 45-70: with MRI
                  strategies$strategy7,                                        # 7. PSA-Risk-adaptive : 50-60: With MRI
                  strategies$strategy8,                                        # 8. PSA-Risk-adaptive : 50-70: With MRI
                  strategies$strategy9,                                        # 9. DRE only: 45-75: No MRI
                  strategies$strategy10B                                       # 16.  No screening: MRI clinical = True
            )


# Additional arguments not included in the list
additional_args <- list(from = 45, start_screening = 45, stop_screening = 76)

# Combine the strategy list with the additional arguments
table_args <- c(strategies, additional_args)

table_2_with_mri  <- do.call(myreport.Fun.A_6_strategies, table_args)
# Save the tables to an Excel file
# Set the timestamp
timestamp2 <- format(Sys.time(), "%Y-%m-%d")

# Create the file names
file_name_1 <- paste0("../Result_ICJ_manuscript/Table_2_Base_case_10 strategies_", timestamp2, ".xlsx")

# Save the table as excel file
write.xlsx(table_2_with_mri, file = file_name_1)
##=======================================================================================================================



