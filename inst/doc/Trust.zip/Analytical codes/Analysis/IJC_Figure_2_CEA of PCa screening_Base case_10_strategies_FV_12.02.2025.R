#=======================================================================================================================
#FILENAME: EU manuscript:  Figure 2_CEA of PCa screening_Base case_FV
# PROJECT: Cost-effectiveness of prostate cancer screening strategies in Germany: a population-based microsimulation study
# PURPOSE: To generate Figures for the manuscript
# AUTHOR: Trust Muchadeyi adapted from Shuang Hao

# CREATED: 2023-06-19
# LAST UPDATED: 2024-05-01

## R version: R-4.3.1

# INPUT DATA: 
# NA 
# OUTPUT Data
# Output 1: "../Output_EU_submitted_version/Figure 2_CEA of PCa screening_Base case_FV_Submitted__FV.pdf"
#=======================================================================================================================
# Define a vector of package names
packages <- c("ggplot2", "dplyr", "tidyr", "ggrepel", "openxlsx", "prostata", 
              "scales", "grid","gridExtra", "gtable", "cowplot", "extrafont", "Cairo", "here")

# Loop through each package name
for (pkg in packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
  library(pkg, character.only = TRUE)
}

font_import()  # It might take some time as it scans your system for all fonts.
loadfonts(device = "win")  # For Windows bitmap output
loadfonts(device = "pdf")  # For PDF output
##=======================================================================================================================
# Figure 2: Cost−effectiveness plane: Base case, healthcare perspective, MRI clinical = TRUE: Discounted at 3%: QALYs
##=======================================================================================================================
# Results based on the healthcare perspective
# Using the 10 000 000 000 base population
dCosts <- c(167773567,	175088582,	164641764,	172328094,	172961088,	188124990,	169971493,	185795639,	203229982,	165836085)-165836085   # Delta costs compared with no screening (Incremental costs)

dQALYs <- c(1913379,	1913470,	1913406,	1913502,	1913279,	1913518,	1913295,	1913548,	1913043,	1912587)- 1912587   # Delta QALYs compared with no screening (Incremental QALYs)

# Ensure that both vectors have the same length
if(length(dQALYs) == length(dCosts)) {
  Base <- data.frame(dQALYs, dCosts)
} else {
  warning("The lengths of dQALYs and dCosts vectors are different.")
}

strategy_descriptions <- c("PSA-Risk-adaptive: 45-60: No MRI",          #1
                           "PSA-Risk-adaptive: 45-70: No MRI",          #2
                           "PSA-Risk-adaptive: 50-60: No MRI",          #3
                           "PSA-Risk-adaptive: 50-70: No MRI",          #4
                           "PSA-Risk-adaptive: 45-60: With MRI",        #5
                           "PSA-Risk-adaptive: 45-70: With MRI",        #6
                           "PSA-Risk-adaptive: 50-60: With MRI",        #7
                           "PSA-Risk-adaptive: 50-70: With MRI",        #8
                           "DRE only: 45-75: No MRI",                   #9
                           "No screening*")                             #10

Base <- data.frame(dQALYs,dCosts)

# Assuming that the row names of your data frame are numbered 1 to 23
Base$Label <- factor(strategy_descriptions[seq_along(dQALYs)], levels = strategy_descriptions)

#Base$Label <- strategy_descriptions[as.numeric(rownames(Base))]

# Setting the labels as a factor with predefined levels
Base$Label <- factor(Base$Label, levels = strategy_descriptions)

# Since there are no WTP thresholds in Germany we will use arbitrary ones as follows
WTP_lower <- 20000
WTP_moderate <- 50000
WTP_high <- 100000

# Utility to calculate the cost-efficiency frontier
# Given x and y, return a list with x and y for the concave frontier or the convex frontier
# x and y should be the same length and have no missing values.
frontier <- function (x, y, concave=TRUE, convex=NULL) 
{
  ## check arguments
  stopifnot(is.logical(concave),
            is.null(convex) || is.logical(convex),
            is.numeric(x),
            is.numeric(y),
            length(x) == length(y),
            !any(is.na(x)),
            !any(is.na(y)))
  ## Change concave if convex is defined
  if (!is.null(convex))
    concave <- !convex
  if (concave) {
    ichull <- grDevices::chull(cbind(x, y))
    ## case: length == 0
    if ((n <- length(ichull)) == 0)
      return(NULL)
    ## case: length == 1
    if (n == 1)
      return(list(x=x[ichull], y=y[ichull]))
    ## case: length > 1
    ## if min(x) value is not first in ichull, then re-order
    if ((iminx <- which.min(x[ichull])) > 1) {
      ichull <- ichull[c(iminx:n, 1:(iminx-1))]
    }
    ## find those that are increasing for x and y
    include <- c(TRUE,diff(x[ichull])>0 & diff(y[ichull])>0)
    list(x=x[ichull][include], y=y[ichull][include])
  } else # convex case
    with(Recall(y,x,concave=TRUE), list(x=y, y=x))
}


# Extend the vector to 10 highly contrasting colors
my_colors <- c("magenta", "#FFFF00","green", "#000000",  # Original colors
               "#0000CD", "#8A2BE2",  # Original colors
               "#FFA500", "#00FFFF", "#FF0000", "#800080")  # New colors


# Know the following line types
# linetype = 0 gives blank lines
# linetype = 1 gives solid lines (the default)
# linetype = 2 gives dashed lines
# linetype = 3 gives dotted lines
# linetype = 4 gives dot-dash lines

Plot_frontier = with(Base, data.frame(frontier(`dQALYs`,`dCosts`,convex=TRUE)))

Plot_base_QALYs <- ggplot(Base, mapping=aes(x=`dQALYs`, y=`dCosts`)) + 
  geom_line(data=Plot_frontier, aes(x=x, y=y), linetype=1, color="black", linewidth=2) +
  annotate("text", x=850, y=100000, label="ICER: 80,581€", size=8,
           vjust=0, hjust=0, check_overlap=TRUE, fontface="bold") +
  annotate("text", x=930, y=12000000, label="ICER: 290,344€", size=8,
           vjust=0, hjust=1, check_overlap=TRUE, fontface="bold") +
  geom_point(aes(color=Label, shape=Label), size=8) + 
  scale_shape_manual(name="Strategies compared", values=c(17, 17,17,17, 15, 15, 15,15, 18, 16)) +   
  scale_color_manual(name="Strategies compared", values=my_colors) +  # Use defined colors
  theme_bw() + 
  theme(text=element_text(family= "Palatino Linotype"),
        legend.text=element_text(size=24), #face="bold"),
        legend.title=element_text(size=30, face="bold", hjust=0.5), # Centred title
        legend.key.width=unit(0.5, "cm"),  
        legend.position=c(0.50, 0.850), # or use legend.position=("top", "bottom", "left", "right") or "none" 
        legend.direction="horizontal",  
        legend.box="horizontal",       
        legend.box.spacing=unit(0.1, "cm"),  
        legend.box.margin=margin(0, 0, 0, 0),  
        legend.key.height=unit(2, "lines"),  
        legend.key=element_blank(),
        legend.background=element_rect(fill="white", colour="black"),  
        axis.title.x=element_text(size=30, face="bold"), 
        axis.title.y=element_text(size=30, face="bold"), 
        axis.text=element_text(size=30, face="bold"),
        plot.title=element_blank(), 
        plot.caption=element_text(hjust=0, size=10), 
        plot.margin=margin(1, 1, 1, 1, "cm")) +
  labs(x="Incremental QALYs per 100,000 men", 
       y="Incremental costs per 100,000 men (Million Euros)") +
  scale_y_continuous(breaks = seq(-5000000, 100000000, by = 5000000), limits = c(-5000000, 60000000),labels = function(x) x / 1000000)+
  scale_x_continuous(breaks = seq(0, 1000, by = 200),limits = c(0, 1000))+
  geom_abline(intercept = 0, slope = WTP_lower, linetype = 2, linewidth = 1, color = "#B22222") +
  annotate("text", x = 600, y = 12000000, label = "hWTP: 20,000€", size = 8, hjust = 1, vjust = 0, fontface = "bold") +
  geom_abline(intercept = 0, slope = WTP_moderate, linetype = 2, linewidth = 1, color = "#B22222") +
  annotate("text", x = 600, y = 30000000, label = "hWTP: 50,000€", size = 8, hjust = 1, vjust = 0, fontface = "bold") +
  geom_abline(intercept = 0, slope = WTP_high, linetype = 2, linewidth = 1, color = "#B22222") +
  annotate("text", x = 200, y = 20000000, label = "hWTP: 100,000€", size = 8, hjust = 1, vjust = 0, fontface = "bold") +
  guides(shape=guide_legend(title.position="top", title.hjust=0.5, ncol=2, byrow=TRUE),
         color=guide_legend(title.position="top", title.hjust=0.5, ncol=2, byrow=TRUE))

Plot_base_QALYs
##=======================================================================================================================
#Plotting the plot
##=======================================================================================================================
# Set version number
version <- "IJC"

# Get today's date
today_date <- Sys.Date()

# Create directory if it doesn't exist
output_dir <- "../Output_IJC_manuscript"
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# Construct dynamic file names for both PNG and PDF
png_filename <- paste0(output_dir, "/Figure 2_CE plane_Base case_10_strategies_", 
                       version, "_FV_", today_date, ".png")
pdf_filename <- paste0(output_dir, "/Figure 2_CE plane_Base case_10_strategies_", 
                       version, "_FV_", today_date, ".pdf")

# Save as .png using Cairo
tryCatch({
  CairoPNG(filename = png_filename, width = 15, height = 15, units = "in", res = 900)
  print(Plot_base_QALYs)
  dev.off()
  cat("PNG file saved successfully.\n")
}, error = function(e) {
  cat("Failed to save PNG file: ", e$message, "\n")
})

tryCatch({
  CairoPDF(pdf_filename, width = 15, height = 15)
  print(Plot_base_QALYs)
  dev.off()
  cat("PDF file saved successfully.\n")
}, error = function(e) {
  cat("Failed to save PDF file: ", e$message, "\n")
})
