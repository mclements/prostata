#=======================================================================================================================
# FILENAME: EU manuscript: Figure 3A_and_3B_CEA of PCa screening_Sensitivity analyses 
# PROJECT: Cost-effectiveness of prostate cancer screening strategies in Germany: a population-based microsimulation study
# PURPOSE: To generate Figure 4 for the manuscript
# AUTHOR: Trust Muchadeyi adapted from Shuang Hao

# CREATED: 2023-06-19
# LAST UPDATED: 2024-05-01

## R version: R-4.3.1

# INPUT DATA: 
# Input 1: DSA dataset "..\\Data\\Trust_DSA_six_strategies_EU_manuscript_FV_Revised_2024-02-09_18-03-21.Rdata" 
# Input 2: PSA dataset: "..\\Data\\Trust_PSA_multiple_strategies1000_iterations_1e+06_simulations_2024-01-01_09-16-18.Rdata"

# OUTPUT Data
# Output 1: "../Output_PHD_Monogram/Fig_32_PSA_CE_plane_and CEAC_.pdf"
#=======================================================================================================================
# Define a vector of package names
packages <- c("ggplot2", "dplyr", "tidyr", "ggrepel", "openxlsx", "prostata", 
              "scales", "grid","gridExtra", "gtable", "cowplot", "extrafont", "Cairo")


# Loop through each package name
for (pkg in packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
  library(pkg, character.only = TRUE)
}

font_import()  # It might take some time as it scans your system for all fonts.
loadfonts(device = "win")  # For Windows bitmap output
loadfonts(device = "pdf")  # For PDF output
##=======================================================================================================================

load(file = "..\\Data\\PhD_PSA_multiple_strategies__BCEA_report_1000_iterations_1e+06_simulations_2024-12-03.Rdata")

#=============================================================================================================
# Figure XXX CEAC for probabilistic sensitivity analysis
##=======================================================================================================================
# A package designed to post-process the simulations results (particularly of a Bayesian analysis) and produce standardised output for the analysis of the results
library(BCEA)
# Function for the reporting

# report
ereport <- function(report) {
  data = do.call(rbind,lapply(report, "[[", "mean_utilities"))
  colnames(data) = 1:11
  data
}
creport <- function(report) {
  data = do.call(rbind,lapply(report, "[[", "mean_costs"))
  colnames(data) = 1:11
  data
}

# bcea accepts, as inputs two matrices,which we denote by e and c.
# e and c contain the simulated values of the effectiveness (QALYs in this regard) and costs, associated with the interventions strategy 1 to strategy7
e = ereport(report)
c = creport(report)
head(e)
head(c)

# Selecting relevant strategies
e = e[, c(1:9, 11)]
c = c[, c(1:9, 11)]
# Call the bcea function to processes the matrices for the costs and effectiveness so that the model output is in the correct form for other functions in the package BCEA
# Assign the called function to an object m of class bcea
# The option ref=2 instructs R to consider the second intervention(i.e., the one for which the values of the cost and effectiveness measures feature in the second column 

# Define a vector with named colours
my_colors <- c("magenta", "#FFFF00","green", "#000000",  # Original colors
               "#0000CD", "#8A2BE2",  # Original colors
               "#FFA500", "#00FFFF", "#FF0000", "#800080")  # New colors

m = bcea(e,c,
         ref=10,                   # Reference case should be No screening: Compare all with No screening
         Kmax=500000,
         plot =TRUE,                                                    # to give rough plots
         label_vector <- c("PSA-Risk-adaptive: 45-60: No MRI",          #1
                           "PSA-Risk-adaptive: 45-70: No MRI",          #2
                           "PSA-Risk-adaptive: 50-60: No MRI",          #3
                           "PSA-Risk-adaptive: 50-70: No MRI",          #4
                           "PSA-Risk-adaptive: 45-60: With MRI",        #5
                           "PSA-Risk-adaptive: 45-70: With MRI",        #6
                           "PSA-Risk-adaptive: 50-60: With MRI",        #7
                           "PSA-Risk-adaptive: 50-70: With MRI",        #8
                           "DRE only: 45-75: No MRI",                   #9
                           "No screening*")) 
mce = multi.ce(m)
my_ceac_ggplot <-
  function (he, comparison=NULL, pos_legend=c(1,0), graph_params, ceac="p_best_interv",
            line_colors=NULL, ...) {
    
    he <- setComparisons(he, comparison)
    graph_params <- prepare_ceac_params(he,...)
    extra_params <- list(...) # annoyingly defaults colours to "black"...
    ceac_dat <- he[[ceac]]
    n_lines <- ncol(ceac_dat)
    data_psa <- tibble(k = rep(he$k, times = n_lines), ceac = c(ceac_dat), 
                       comparison = as.factor(rep(1:n_lines, each = length(he$k))))
    graph_params <- helper_ggplot_params(he, graph_params)
    legend_params <- make_legend_ggplot(he, pos_legend)
    theme_add <- purrr::keep(extra_params, is.theme)
    ## browser()
    p <- ggplot(data_psa, aes(.data$k, .data$ceac, color=.data$comparison)) + 
      geom_line(linewidth = 4) +  # Increase line size here
      theme_ceac() + 
      theme_add + 
      scale_y_continuous(limits = c(0, 1)) +
      do.call(labs, graph_params$annot) + 
      do.call(theme, legend_params) + 
      scale_linetype_manual("", labels = graph_params$plot$labels, 
                            values = graph_params$plot$line$types) + 
      scale_color_manual("", labels = graph_params$plot$labels, values = line_colors)
    return(p)
  }

environment(my_ceac_ggplot) <- environment(BCEA::bcea)

# Colour and Line Types
color_vector <- my_colors   # colours should be 23 here, seven strategies
label_vector <- c("PSA-Risk-adaptive: 45-60: No MRI",          #1
                  "PSA-Risk-adaptive: 45-70: No MRI",          #2
                  "PSA-Risk-adaptive: 50-60: No MRI",          #3
                  "PSA-Risk-adaptive: 50-70: No MRI",          #4
                  "PSA-Risk-adaptive: 45-60: With MRI",        #5
                  "PSA-Risk-adaptive: 45-70: With MRI",        #6
                  "PSA-Risk-adaptive: 50-60: With MRI",        #7
                  "PSA-Risk-adaptive: 50-70: With MRI",        #8
                  "DRE only: 45-75: No MRI",                   #9
                  "No screening*")

# CEAC plot with consistent styling
CEAC <- my_ceac_ggplot(mce, 
                       xlab = "Cost-effectiveness threshold (Euros)",
                       ylab = "Probability of cost-effectiveness",
                       line_colors = color_vector,
                       pos = c(0, 0.5)) +
  # Apply a theme with a white background and specific font, matching settings from your main plot
  theme_bw() +
  theme(#text = element_text(family = "Times"), # Changed to 'Times' to match other plots
    legend.text = element_text(size = 22), # Adjusted to match other plots
    legend.title = element_text(size = 24, face = "bold"), # Consistent with main plot
    legend.key.width = unit(0.5, "cm"), # Consistent key width
    legend.position = c(0.55, 0.85), # Specific position in this plot
    legend.direction = "horizontal",
    legend.box = "horizontal",
    legend.box.spacing = unit(0.1, "cm"),
    legend.box.margin = margin(0, 0, 0, 0),
    legend.key.height = unit(2, "lines"),
    legend.key = element_blank(),
    legend.background = element_rect(fill = "white", colour = "black"),
    axis.title.x = element_text(size = 24, face = "bold"),
    axis.title.y = element_text(size = 24, face = "bold"),
    axis.text = element_text(size = 24, face = "bold"),
    plot.title = element_blank(),
    plot.margin = margin(1, 1, 1, 1, "cm")) +
  # Add vertical lines at specified willingness-to-pay thresholds
  geom_vline(xintercept = c(20000, 50000, 100000, 250000,450000), linetype = 2, color="#B22222", linewidth = 1) +
  # Custom x-axis breaks and labels
  #scale_y_continuous(breaks = seq(-0, 1, by = 0.5), labels = function(x) x / 1000000)+
  scale_x_continuous(breaks = seq(0, 500000, 100000), labels = scales::comma) +
  # Manual scale for color with custom labels and values
  scale_color_manual(name = "Strategies compared", labels = label_vector, values = color_vector) +
  # Custom guide settings for the legend
  guides(color = guide_legend(ncol = 2, byrow = TRUE, title.position = "top", title.hjust = 0.5)) +
  # Labels for axes
  labs(x = "Willingness to pay threshold (Euros per QALY)")

# Printing the plot
print(CEAC)
##=======================================================================================================================
#Plotting the plot
##=======================================================================================================================
# Set version number
version <- "IJC"

# Get today's date
today_date <- Sys.Date()

# Create directory if it doesn't exist
output_dir <- "../Output_IJC_manuscript"
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# Construct dynamic file names for both PNG and PDF
png_filename <- paste0(output_dir, "/Figure 4_CEAC plane_PSA_ten_strategies_", 
                       version, "_FV_", today_date, ".png")
pdf_filename <- paste0(output_dir, "/Figure 4_CEAC plane_PSA_ten_strategies_", 
                       version, "_FV_", today_date, ".pdf")

# Save as .png using Cairo
tryCatch({
  CairoPNG(filename = png_filename, width = 15, height = 15, units = "in", res = 900)
  print(CEAC)
  dev.off()
  cat("PNG file saved successfully.\n")
}, error = function(e) {
  cat("Failed to save PNG file: ", e$message, "\n")
})

tryCatch({
  CairoPDF(pdf_filename, width = 15, height = 15)
  print(CEAC)
  dev.off()
  cat("PDF file saved successfully.\n")
}, error = function(e) {
  cat("Failed to save PDF file: ", e$message, "\n")
})
