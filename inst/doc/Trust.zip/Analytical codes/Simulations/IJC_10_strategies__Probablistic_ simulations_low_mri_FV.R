##=======================================================================================================================
## FILENAME: Study figures 
# PROJECT: Cost-effectiveness of prostate cancer screening strategies in Germany: a population-based microsimulation study
## PURPOSE: To conduct the probabilistic sensitivity analysis considering uncertainties in combination
## AUTHOR: Muchadeyi Trust adapted from Shuang Hao

# CREATED: 2023-06-12

# LAST UPDATED: 2023-10-14

# R version: R-4.3.1

## INPUT DATA: 
## OUTPUT: Z:/Study5/

## R version: R-4.2.3
#=======================================================================================================================
# Set up: 
#=======================================================================================================================

packages <- c("dplyr","prostata", "parallel","here")

# Loop through each package name
for(pkg in packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    # If the package is not installed, install it
    install.packages(pkg)
  }
  # Load the package
  library(pkg, character.only = TRUE)
}
#=======================================================================================================================
# Update baseline cost parameters
##=======================================================================================================================

modify_ALL_CostParameters <- function(parameters,MRI_diagnostics = FALSE, MRI_active_surveillance = TRUE, DRE = FALSE, scale = 1) {
  
  #if (is.null(MRI_patient)) {
  #stop("MRI_patient is NULL")
  #}
  
  parm <- modifyList(parameters, list(MRI_screen = MRI_diagnostics, DRE = DRE, MRI_active_surveillance = MRI_active_surveillance))
  
  # Modify the cost parameters
  cost_parameters =  c("Invitation" = 0.86+0.86,                                # Invitation letter
                       "Opportunistic DRE" = 0.2*21.26+ 0.5*(16.55+13.33),      # Cost for DRE alone: No PSA assay: Factor in that this include CRC 50:50 ratio
                       "Opportunistic PSA" = if (DRE) 4.80+20.81 else (0.2*21.26)+(4.80+20.81)+0.5*(16.55+13.33),
                       "Biopsy" = 66.64,                                        # Systematic biopsy
                       "MRI" = 120+21.60,                                       # MRI cost
                       "Combined biopsy" = 123.74,                              # Biopsy cost (NB: assumes a preceding MRI)
                       "Assessment" = 131.81,                                   # Urologist consultation
                       "Prostatectomy" = 10927.37,                              # Robot assisted surgery
                       "Radiation therapy" = 8872.83,                           # Radiation therapy
                       "Active surveillance - yearly - w/o MRI"  = if (MRI_active_surveillance) 312.722 else 146.186,   # Urology visit and nurse visit
                       "Active surveillance - yearly - with MRI" = if (MRI_active_surveillance) 312.722 else 146.186,   # Urology visit and nurse visit
                       "ADT+chemo" = 28957.76,                  # Drug treatment for metastasis
                       "Post-Tx follow-up - yearly first" = 207.248,            # Urologist and nurse consultation
                       "Post-Tx follow-up - yearly after" = 76.748,             # PSA test sampling
                       "Palliative therapy - yearly" = 40185.68,                # Palliative care cost
                       "Terminal illness" = 40185.68*0.5                        # Terminal illness cost
  )
  # Add the cost parameters to the parm list
  parm$cost_parameters <- cost_parameters*scale
  
  # Return the modified list
  return(parm)
}

#=======================================================================================================================
# Set up the simulations
##=======================================================================================================================
n.sim <- 10^6                                              #  number of individuals
n.psa <- 1000                                             #  number of iterations
cl <- makeCluster(detectCores()-1,type="PSOCK")
set.seed(12345)

## We need to run the simulations based on the joint distributions of selected parameters for the sensitivity analysis
Rgamma <- function(x) stats::rgamma(length(x), 100, 100)
expit=binomial()$linkinv
logit=binomial()$linkfun

# Initialize counter variable
iteration <- 0
scale <- 1

simulateParameters <- function(Base) {
  
  # Increment the counter
  iteration <<- iteration + 1
  
  Newset = Base
  ## Using gamma distribution for health care cost #
  ## Delete productivity losses here since we are using the SHI
  ## Refer back to Shuang's original code if need to add societal perspective arises.
  scale <<- Rgamma(1)   # unidirectional change compare with previous code
  Newset$cost_parameters <- scale*Base$cost_parameters
  
  ## Using logit-normal distribution for health state utility values (HSUVs)
  changed_utilities <- c("Biopsy", "Cancer diagnosis","Prostatectomy part 1",
                         "Prostatectomy part 2",
                         "Radiation therapy part 1","Radiation therapy part 2",
                         "Active surveillance","Postrecovery period",
                         "Palliative therapy")
  index = match(changed_utilities,names(Newset$utility_estimates))
  se = (logit(c(0.940,0.850,0.960,0.970,0.914,0.944,0.99,0.95,0.71))-
          logit(c(0.870,0.750,0.760,0.840,0.866,0.896,0.97,0.91,0.64)))/2/1.96
  Newset$utility_estimates[index] <-
    expit(rnorm(9,logit(c(0.9,0.8,0.86,0.9,0.89,0.92,0.98,0.93,0.68)), se))
  
  ## Using logit-normal distribution for test characteristics
  se = (logit(c(.229,0.465,0.936,0.135,0.151))-logit(c(.147,0.198,0.643,0.028,0.064)))/2/1.96  ##UPDATED
  char <- expit(rnorm(5,logit(c(0.184292639603879, 0.31665222781238, 0.836863639059411, 
                                0.063227239427133, 0.0990348937500625)), se))  ##UPDATED
  
  ## CAREFUL WITH THE ORDER
  nms <- c("pMRIposG0","pMRIposG1","pMRIposG2","pSBxG0ifG1","pSBxG0ifG2")
  for (i in 1:5) {
    stopifnot(nms[i] %in% names(Newset))
    Newset[[nms[i]]] <- char[i]
  }
  
  # Use beta distribution for DRE test characteristics
  # Existing DRE Table from Scroder et al 1998
  dre = data.frame(psa_low=c(0:4,10),
                   psa_high=c(1:4,10,1e6),
                   dre=c(1702,3305,1314,734,1095,217),
                   appa=c(19,119,97,89,254,128), # predicted
                   bx=c(109,296,128,106,249,82),
                   pc=c(4,29,14,35,115,67))
  
  # Explain the variables
  # psa_low and psa_high defines the PSA range at which a biopsy was done
  # dre = the total number of DRE done
  # appa = a priori prevalence assessment (APPA) of prostate cancer in a population = Number of PCA expected if all cases are detected
  # bx = number of biopsies done
  # pc = Number of true positive in from the test
  # number of true negatives = dre-appa-(bx-pc)
  
  # Calculate original deterministic sensitivity and specificity
  # Remember: Sensitivity= True Positives (TP) / [True Positives (TP) + False Negatives (FN)] and
  
  #           Specificity = True Negatives (TN)/ [True Negatives (TN) + False Positives (FP)]
  
  dre = transform(dre,
                  det_sensitivity = pc/appa,
                  det_specificity = (dre-appa-(bx-pc))/(dre-appa))
  
  
  
  # Now instead of deterministic values add a column for stochastic values for sensitivity and specificity based on a beta-binomial model
  # Probabilistic Sensitivity Analysis
  # using a beta distribution
  # The parameters for the beta distribution can be directly derived as (Remember beta-binomial conjugacy):
  # α=x+1
  # β=n−x+1
  
  # Choose the correct x and n for sensitivity and specificity by row from the table
  dre <- 
    mutate(dre, psa_sensitivity = rbeta(6, pc + 1, appa - pc + 1),   # Randomly generate 1 value based on the defined beta
           psa_specificity = rbeta(6, dre - appa - bx + pc + 1, appa + bx - pc + 1))
  
  Newset$newdre = with(dre, data.frame(psa=psa_low, sensitivity= psa_sensitivity, specificity = psa_specificity))
  
  print(Newset$newdre)
  
  Newset
}
#=======================================================================================================================
# Face validation: Initialize matrix to store ICER values: F
##=======================================================================================================================

# 1. Initialize the report list

report <- list()

#=======================================================================================================================
# Running the simulations: lapply = do this for  each element of the list and return the results in a list format 
##=======================================================================================================================

for (i in 1:n.psa) {
  #Group 1: Probase No MRI
  # Initialize parameters and update cost parameters and modify selected other input parameters: 
  # Set MRI screen = FALSE = MRI_diagnostics 
  Base <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
    modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
    modifyList(list(start_screening=45,               # or 50
                    psaThreshold=3,                   # for referral
                    risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                    risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                    risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                    stop_screening=60,                # Always 60 for all Probase strategies
                    currency_rate =1,                 # OBS!! Do this for all the simulation
                    use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                    rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                    screeningParticipation=0.75,      # Crude assumption
                    biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                    negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                    MRI_clinical =FALSE,
                    MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
    )
    )
  
  # Generate a new set of parameters for each simulation run based on the random sampling distributions
  # Also updates scale and this should only change when the moving to the next iteration
  newP_PSA_noMRI = simulateParameters(Base)       
  
  #=======================================================================================================================
  # Strategy I: PSA-Risk-adaptive: 45-60: No MRI
  #=======================================================================================================================
  strategy1 = callFhcrc(n.sim, screen="probase",               
                        pop=1950,
                        parm=newP_PSA_noMRI,
                        cl=cl)
  
  #=======================================================================================================================
  # Strategy II: PSA-Risk-adaptive: 45-70: No MRI
  #=======================================================================================================================
  strategy2 = callFhcrc(n.sim, screen="probase",               
                        pop=1950,
                        parm=modifyList(newP_PSA_noMRI,
                                        list(stop_screening=70)),
                        cl=cl)
  
  #=======================================================================================================================
  # Strategy III: PSA-Risk-adaptive: 50-60: No MRI
  #=======================================================================================================================
  strategy3 = callFhcrc(n.sim, screen="probase",              
                        pop=1950,
                        parm=modifyList(newP_PSA_noMRI,
                                        list(start_screening=50)),
                        cl=cl)
  
  #=======================================================================================================================
  # Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
  #=======================================================================================================================
  strategy4 = callFhcrc(n.sim, screen="probase",              
                        pop=1950,
                        parm=modifyList(newP_PSA_noMRI,
                                        list(start_screening=50,
                                             stop_screening=70)),
                        cl=cl)
  
  #=======================================================================================================================
  # #Group 2: PSA-Risk-adaptive : with MRI 
  #=======================================================================================================================
  newP_PSA_wMRI <- modifyList(newP_PSA_noMRI,                         
                              list(MRI_screen=TRUE,
                                   MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages      
  
  #=======================================================================================================================
  # Strategy V: PSA-Risk-adaptive : 45-60: With MRI
  #=======================================================================================================================
  strategy5 = callFhcrc(n.sim, screen="probase",            
                        pop=1950,
                        parm= newP_PSA_wMRI,
                        cl=cl)
  
  #=======================================================================================================================
  # Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
  #=======================================================================================================================
  strategy6 = callFhcrc(n.sim, screen="probase",            
                        pop=1950,
                        parm=modifyList(newP_PSA_wMRI,
                                        list(stop_screening=70)),
                        cl=cl)
  #=======================================================================================================================
  # Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
  #=======================================================================================================================
  strategy7 = callFhcrc(n.sim, screen="probase",            
                        pop=1950,
                        parm=modifyList(newP_PSA_wMRI,
                                        list(start_screening=50)),
                        cl=cl)
  #=======================================================================================================================
  # Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
  #=======================================================================================================================
  strategy8 = callFhcrc(n.sim, screen="probase",            
                        pop=1950,
                        parm=modifyList(newP_PSA_wMRI,
                                        list(start_screening=50,
                                             stop_screening=70)),
                        cl=cl)
  #=======================================================================================================================
  #Group 3: DRE only
  #=======================================================================================================================
  newP_DRE_only <- modify_ALL_CostParameters(newP_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
    modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                    dre_annual_interval=1,                    # Rescreening for DRE positive
                    germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                    stop_screening=75,                        # Always 75 for DRE screening
                    MRI_clinical=FALSE,
                    MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                    MRI_screen=FALSE,
                    negbx_to_regular=TRUE,
                    dre_to_biopsy=TRUE))
  
  #=======================================================================================================================
  #Strategy IX: DRE Only: No PSA no MRI
  #=======================================================================================================================
  # Guidelines or practice
  strategy9 = callFhcrc(n.sim, screen="germany_2021",      
                        pop=1950,
                        parm=newP_DRE_only,
                        cl=cl)
  
  #=======================================================================================================================
  # Strategy X: No screening with  or without MRI diagnostics 
  #=======================================================================================================================
  # Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
  # Note that MRI_treatment = TRUE is still the setting
  newP_No_screening=modify_ALL_CostParameters(newP_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 
  
  # Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
  # Note that MRI_treatment = TRUE is still the setting
  strategy10A = callFhcrc(n.sim, screen="noScreening",
                          pop=1950,
                          parm=newP_No_screening, 
                          cl=cl)
  
  newP_No_screening_wMRI_clinical=modify_ALL_CostParameters(newP_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine
  
  # Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
  # Note that MRI_treatment = TRUE is still the setting
  strategy10B = callFhcrc(n.sim, screen="noScreening",
                          pop=1950,
                          parm=newP_No_screening_wMRI_clinical, 
                          cl=cl)
  
  #=======================================================================================================================
  # ICER calculations and reporting
  ##=======================================================================================================================
    
  ## Save the simulations to avoid re-running them later 
  strategies = list(strategy1,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5,       # PSA-Risk-adaptive : 45-60: With MRI 
                    strategy6,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy7,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy9,       # DRE only: 45-75: No MRI
                    strategy10A,     # No screening: MRI clinical = FALSE
                    strategy10B)     # No screening: MRI clinical = True 
   
  iteration <<- i
  message(paste(i, "iterations done,", n.psa - i, "to go"))
    
    ## Return report: mean_costs and mean_utilities
  summaries = lapply(list(strategy1,       # PSA-Risk-adaptive : 45-60: No MRI 
                          strategy2,       # PSA-Risk-adaptive : 45-70: No MRI
                          strategy3,       # PSA-Risk-adaptive : 50-60: No MRI
                          strategy4,       # PSA-Risk-adaptive : 50-70: No MRI
                          strategy5,       # PSA-Risk-adaptive : 45-60: With MRI
                          strategy6,       # PSA-Risk-adaptive : 45-70: No MRI
                          strategy7,       # PSA-Risk-adaptive : 50-60: With MRI
                          strategy8,       # PSA-Risk-adaptive : 50-70: No MRI
                          strategy9,       # DRE only: 45-75: No MRI
                          strategy10A,     # No screening: MRI clinical = FALSE
                          strategy10B),     # No screening: MRI clinical = True
                     summary, from = 45)
    report[[i]] <- data.frame(
      mean_costs = sapply(summaries, function(object) object$healthsector.costs),
      mean_utilities = sapply(summaries, function(object) object$QALE)
    )
  
    }
# Stop the cluster after all tasks in this iteration are complete
stopCluster(cl)

# Generate timestamp
timestamp <- format(Sys.time(), "%Y-%m-%d")

# Save the report for future analysis
# Create the file name
file_name <- paste0("..\\Data\\PhD_PSA_multiple_strategies__BCEA_report_low mri_",n.psa, "_iterations_", n.sim, "_simulations_", timestamp, ".Rdata")

save(report, file=file_name)

#===============================THE END===========================================================================================


