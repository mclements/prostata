# FILENAME: Functions used for analysis and reporting
# PROJECT: Cost-effectiveness of prostate cancer screening strategies in Germany: a population-based micro simulation study
# PURPOSE: Cost parameters specific to Germany as well as  discounting and tabulating functions
# AUTHOR: Trust Muchadeyi adapted from Shuang Hao

# CREATED: 2023-05-20

## R version: R-4.2.3 and compatible with R-4.4.3

# INPUT DATA: 
# OUTPUT DATA:
##=======================================================================================================================
#New:Update cost parameters from the previous version
##=======================================================================================================================

modify_ALL_CostParameters <- function(parameters,MRI_diagnostics = FALSE, MRI_active_surveillance = TRUE, DRE = FALSE, scale = 1) {
  
  #if (is.null(MRI_patient)) {
  #stop("MRI_patient is NULL")
  #}
  
  parm <- modifyList(parameters, list(MRI_screen = MRI_diagnostics, DRE = DRE, MRI_active_surveillance = MRI_active_surveillance))
  
  # Modify the cost parameters
  cost_parameters =  c("Invitation" = 0.86+0.86,                                # Invitation letter
                       "Opportunistic DRE" = 0.2*21.26+ 0.5*(16.55+13.33),      # Cost for DRE alone: No PSA assay: Factor in that this include CRC 50:50 ratio
                       "Opportunistic PSA" = (0.2*21.26)+(4.80+20.81)+0.5*(16.55+13.33), # PSA costs
                       "Biopsy" = 66.64,                                        # Systematic biopsy
                       "MRI" = 500+21.60,                                       # MRI cost
                       "Combined biopsy" = 123.74,                              # Biopsy cost (NB: assumes a preceding MRI)
                       "Assessment" = 131.81,                                   # Urologist consultation
                       "Prostatectomy" = 10927.37,                              # Robot assisted surgery
                       "Radiation therapy" = 8872.83,                           # Radiation therapy
                       "Active surveillance - yearly - w/o MRI"  = if (MRI_active_surveillance) 691.711 else 146.186,   # Urology visit and nurse visit
                       "Active surveillance - yearly - with MRI" = if (MRI_active_surveillance) 691.711 else 146.186,   # Urology visit and nurse visit
                       "ADT+chemo" = 28957.76,                  # Drug treatment for metastasis
                       "Post-Tx follow-up - yearly first" = 207.248,            # Urologist and nurse consultation
                       "Post-Tx follow-up - yearly after" = 76.748,             # PSA test sampling
                       "Palliative therapy - yearly" = 40185.68,                # Palliative care cost
                       "Terminal illness" = 40185.68*0.5                        # Terminal illness cost
  )
  # Add the cost parameters to the parm list
  parm$cost_parameters <- cost_parameters*scale
  
  # Return the modified list
  return(parm)
}

##=======================================================================================================================
# A. Discount function
##=======================================================================================================================

discounted <- function(object,discountRate,from=45) {
  if (from>0) {
    object$n <- sum(subset(object$summary$prev,age==from)$count)
    object$summary$ut <- subset(object$summary$ut, age>=from)
    object$summary$pt <- subset(object$summary$pt, age>=from)
    object$summary$prev <- subset(object$summary$prev, age>=from)
    object$summary$events <- subset(object$summary$events, age>=from)
    object$societal.costs <- subset(object$societal.costs, age>=from)
    object$healthsector.costs <- subset(object$healthsector.costs, age>=from)
  }
  LE <- local({
    pt <- xtabs(pt~age,data=object$summary$pt)
    ages <- as.numeric(names(pt))+0.5 # mid-point approximation
    sum((1/(1+discountRate))^(ages-from)*pt)/object$n
  })
  societal.costs <- local({
    costs <- xtabs(costs~age,data=object$societal.costs)
    ages <- as.numeric(names(costs))+0.5 # mid-point approximation
    undiscounted.costs <- costs*(1+object$simulation.parameters$discountRate.costs)^ages
    sum((1/(1+discountRate))^(ages-from)*undiscounted.costs)/object$n
  })
  healthsector.costs <- local({
    costs <- xtabs(costs~age,data=object$healthsector.costs)
    ages <- as.numeric(names(costs))+0.5 # mid-point approximation
    undiscounted.costs <- costs*(1+object$simulation.parameters$discountRate.costs)^ages
    sum((1/(1+discountRate))^(ages-from)*undiscounted.costs)/object$n
  })
  utilities <- local({
    utilities <- xtabs(ut~age,data=object$summary$ut)
    ages <- as.numeric(names(utilities))+0.5 # mid-point approximation
    undiscounted.utilities <-
      utilities*(1+object$simulation.parameters$discountRate.effectiveness)^ages
    sum((1/(1+discountRate))^(ages-from)*undiscounted.utilities)/object$n
  })
  list(utilities=utilities,
       societal.costs=societal.costs,
       healthsector.costs=healthsector.costs,
       LE=LE)
}

myreport <- function(object,names,per=1e5,subset=TRUE,from=45) {            # I assume this means reporting per 100,000 men---4/5[!!! 4 in Shuang's]
  n <- sum(subset(object$summary$prev,age==from)$count) # number alive at 'from'
  sum(subset(object$summary$events, event %in% names & subset & age>=from)$n)/n*per
}

## Note: this function is currently unused
myreport.add <- function(object,names,per=1e5,subset=TRUE,from=45) {
  n <- sum(subset(object$summary$prev,age==from)$count) # number alive at 'from'
  sum(subset(object$summary$events, grade %in% names & subset & age>=from)$n)/n*per
}

##=======================================================================================================================
# B. Table A: Model outcomes results
##=======================================================================================================================

myreport.Fun.A_6_strategies <- function(..., from = 45, start_screening = 45, stop_screening = 75) {
  strategies <- list(...)
  num_strategies <- length(strategies)
  if (num_strategies != 10) {
    stop("This function requires exactly 10 strategies.")
  }
  
  olddiscounted <- discounted
  discounted <- function(...) olddiscounted(..., from = from)
  oldmyreport <- myreport
  myreport <- function(...) oldmyreport(..., from = from)
  
  myreport.A <- matrix(nrow = 28, ncol = num_strategies) # Update to 28 rows for the new ICER calculation
  
  # Reference strategy for ICER calculation
  reference_strategy <- strategies[[10]]
  
  # Efficient frontier strategies
  frontier_strategies <- c(10, 3, 8)
  
  # Strategy descriptions
  strategy_descriptions <- c("PSA-Risk-adaptive: 45-60: No MRI",          #1
                             "PSA-Risk-adaptive: 45-70: No MRI",          #2
                             "PSA-Risk-adaptive: 50-60: No MRI",          #3
                             "PSA-Risk-adaptive: 50-70: No MRI",          #4
                             "PSA-Risk-adaptive: 45-60: With MRI",        #5
                             "PSA-Risk-adaptive: 45-70: With MRI",        #6
                             "PSA-Risk-adaptive: 50-60: With MRI",        #7
                             "PSA-Risk-adaptive: 50-70: With MRI",        #8
                             "DRE only: 45-75: No MRI",                   #9
                             "No screening*")                             #10
  
  # Populate the matrix with data
  for (i in 1:num_strategies) {
    strategy <- strategies[[i]]
    
    # DRE Test
    myreport.A[2, i] <- myreport(strategy, "toDRE", subset = (strategy$summary$event$age >= start_screening & strategy$summary$event$age < stop_screening))
    
    # PSA Screening Tests
    myreport.A[3, i] <- myreport(strategy, "toScreen", subset = (strategy$summary$event$age >= start_screening & strategy$summary$event$age < stop_screening))
    
    # MRI Events
    myreport.A[4, i] <- myreport(strategy, "toMRI")
    
    # Total Number of Biopsies
    myreport.A[5, i] <- myreport(strategy, c("toClinicalDiagnosticBiopsy", "toScreenInitiatedBiopsy"))
    
    # Clinically-initiated Biopsies
    myreport.A[6, i] <- myreport(strategy, "toClinicalDiagnosticBiopsy")
    
    # Screen-initiated Biopsies
    myreport.A[7, i] <- myreport(strategy, "toScreenInitiatedBiopsy")
    
    # Total Lifetime Number of Diagnosed PCa
    myreport.A[8, i] <- myreport(strategy, c("toClinicalDiagnosis", "toScreenDiagnosis"))
    
    # Screening Period Number of PCa Diagnosed
    myreport.A[9, i] <- myreport(strategy, c("toClinicalDiagnosis", "toScreenDiagnosis"), 
                                 subset = (strategy$summary$event$age >= start_screening & 
                                             strategy$summary$event$age < strategy$summary$event$stop_screening))
    
    # Clinically Diagnosed PCa
    myreport.A[10, i] <- myreport(strategy, "toClinicalDiagnosis")
    
    # Screen Diagnosed PCa
    myreport.A[11, i] <- myreport(strategy, "toScreenDiagnosis")
    
    # Localised PCa with Gleason < 7
    myreport.A[12, i] <- myreport(strategy, c("toClinicalDiagnosis", "toScreenDiagnosis", "toLocalised"),
                                  subset = (strategy$summary$event$grade %in% "Gleason_le_6"))
    
    # Localised PCa with Gleason = 7
    myreport.A[13, i] <- myreport(strategy, c("toClinicalDiagnosis", "toScreenDiagnosis", "toLocalised"),
                                  subset = (strategy$summary$event$grade %in% "Gleason_7"))
    
    # Localised PCa with Gleason > 7
    myreport.A[14, i] <- myreport(strategy, c("toClinicalDiagnosis", "toScreenDiagnosis", "toLocalised"),
                                  subset = (strategy$summary$event$grade %in% "Gleason_ge_8"))
    
    # Metastatic PCa Diagnosed
    myreport.A[15, i] <- myreport(strategy, "toMetastatic")
    
    # Estimated Overdiagnosed PCa
    myreport.A[16, i] <- myreport(strategy, "toOverDiagnosis")
    
    # Prostate Cancer Deaths
    myreport.A[17, i] <- myreport(strategy, "toCancerDeath")
    
    # Undiscounted Life Years
    myreport.A[18, i] <- discounted(strategy, 0)$LE * 1e5
    
    # Discounted Life Years at 3%
    myreport.A[19, i] <- discounted(strategy, 0.03)$LE * 1e5
    
    # Undiscounted Utilities
    myreport.A[20, i] <- discounted(strategy, 0)$utilities * 1e5
    
    # Discounted Utilities at 3%
    myreport.A[21, i] <- discounted(strategy, 0.03)$utilities * 1e5
    
    # Discounted Utilities at 5%
    myreport.A[22, i] <- discounted(strategy, 0.05)$utilities * 1e5
    
    # Healthcare Perspective Costs Undiscounted
    myreport.A[24, i] <- discounted(strategy, 0)$healthsector.costs* 1e5
    
    # Healthcare Perspective Costs Discounted at 3%
    myreport.A[25, i] <- discounted(strategy, 0.03)$healthsector.cost* 1e5
    
    # Healthcare Perspective Costs Discounted at 5%
    myreport.A[26, i] <- discounted(strategy, 0.05)$healthsector.cost* 1e5
    
    # ICER Calculation compared to reference strategy
    if (i != 10) {
      cost_diff_ref <- discounted(strategy, 0.03)$healthsector.cost - discounted(reference_strategy, 0.03)$healthsector.cost
      util_diff_ref <- discounted(strategy, 0.03)$utilities - discounted(reference_strategy, 0.03)$utilities 
      myreport.A[27, i] <- cost_diff_ref / util_diff_ref
    } else {
      myreport.A[27, i] <- NA # Set ICER as NA for the reference strategy
    }
    
    # ICER Calculation for efficient frontier
    if (i %in% frontier_strategies) {
      next_lower_strategy_index <- which(frontier_strategies == i) - 1
      if (next_lower_strategy_index >= 1) {
        next_lower_strategy <- strategies[[frontier_strategies[next_lower_strategy_index]]]
        cost_diff_frontier <- discounted(strategy, 0.03)$healthsector.cost - discounted(next_lower_strategy, 0.03)$healthsector.cost
        util_diff_frontier <- discounted(strategy, 0.03)$utilities - discounted(next_lower_strategy, 0.03)$utilities
        myreport.A[28, i] <- cost_diff_frontier / util_diff_frontier
      } else {
        myreport.A[28, i] <- "First on Frontier"
      }
    } else {
      myreport.A[28, i] <- "Dominated"
    }
  }
  
  # Set column names
  colnames(myreport.A) <- strategy_descriptions
  
  # Set row names
  rownames(myreport.A) <- c("Outcomes per 100,000 men",                  #1
                            "Number of DRE test",                        #2
                            "Number of PSA tests",                       #3
                            "Number of MRI events",                      #4
                            "Total number biopsy",                       #5
                            "Number of clinically-initiated biopsies",   #6 
                            "Number of screen-initiated biopsies",       #7 
                            "Number of diagnosed PCa",                   #8
                            "Screening period number of PCa Diagnosed",  #9
                            "Number of clinically diagnosed PCa",        #10 
                            "Number of screen diagnosed PCa",            #11  
                            "Number of Localised and G < 7",             #12 
                            "Number of Localised and G = 7",             #13 
                            "Number of Localised and G > 7",             #14 
                            "Number of metastatic PCa diagnosed",        #15
                            "Estimated overdiagnosed PCa",               #16
                            "Prostate cancer deaths",                    #17  
                            "LY, undiscounted",                          #18
                            "LY, discounted at 3%",                      #19
                            "QALYs, undiscounted",                       #20 
                            "QALYs, discounted at 3%",                   #21 
                            "QALYs, discounted at 5%",                   #22
                            "Costs (M€) per 100,000 men",                #23
                            "Healthcare perspective, undiscounted",      #24
                            "Healthcare perspective, discounted at 3%",  #25
                            "Healthcare perspective, discounted at 5%",  #26
                            "ICERs (€ per QALY):Compared with No screening",#27
                            "ICERs on Efficient Frontier (€ per QALY)"   #28
  )
  
  return(as.table(myreport.A))
}

