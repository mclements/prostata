# FILENAME: Base strategies analysis
# PROJECT: Cost-effectiveness of prostate cancer screening strategies in Germany: a population-based microsimulation study
# PURPOSE: To perform the analysis of the simulated results for the base case 
# AUTHOR: Trust Muchadeyi adapted from Shuang Hao

# CREATED: 2023-05-20
# LAST UPDATED: 2024-11.30

## R version: R-4.3.1

# INPUT DATA: 
# OUTPUT Data

# Output 1: "PhD_Monogram_Base_case_strategies simulation:Rdat
# Output 2: "Table_1A_Base_case_10_strategies

#=======================================================================================================================
# Set up: OBS!! Run the analysis functions before running this code
#=======================================================================================================================

packages <- c("ggplot2", "plyr", "dplyr", "tidyr", "prostata", "openxlsx", "parallel", "here", "purrr")

# Loop through each package name
for(pkg in packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    # If the package is not installed, install it
    install.packages(pkg)
  }
  # Load the package
  library(pkg, character.only = TRUE)
}

#======================================================================================================================
# Now run the simulation
#======================================================================================================================

cl <- makeCluster(detectCores()-1,type="PSOCK")
n <- 10^3
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1 = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2 = callFhcrc(n, screen="probase",               
                      pop=1950,
                      parm=modifyList(parm_PSA_noMRI,
                                      list(stop_screening=70)),
                      cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3 = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4 = callFhcrc(n, screen="probase",              
                      pop=1950,
                      parm=modifyList(parm_PSA_noMRI,
                                      list(start_screening=50,
                                           stop_screening=70)),
                      cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6 = callFhcrc(n, screen="probase",            
                      pop=1950,
                      parm=modifyList(parm_PSA_wMRI,
                                      list(stop_screening=70)),
                      cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7 = callFhcrc(n, screen="probase",            
                       pop=1950,
                       parm=modifyList(parm_PSA_wMRI,
                                       list(start_screening=50)),
                       cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8 = callFhcrc(n, screen="probase",            
                      pop=1950,
                      parm=modifyList(parm_PSA_wMRI,
                                      list(start_screening=50,
                                           stop_screening=70)),
                      cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9 = callFhcrc(n, screen="germany_2021",      
                         pop=1950,
                         parm=parm_DRE_only,
                         cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A = callFhcrc(n, screen="noScreening",
                      pop=1950,
                      parm=parm_No_screening, 
                      cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B = callFhcrc(n, screen="noScreening",
                      pop=1950,
                      parm=parm_No_screening_wMRI_clinical, 
                      cl=cl)

stopCluster(cl)

## Save the simulations to avoid re-running them later 
strategies = list(strategy1,       # PSA-Risk-adaptive : 45-60: No MRI 
                  strategy2,       # PSA-Risk-adaptive : 45-70: No MRI
                  strategy3,       # PSA-Risk-adaptive : 50-60: No MRI
                  strategy4,       # PSA-Risk-adaptive : 50-70: No MRI
                  strategy5,       # PSA-Risk-adaptive : 45-60: With MRI 
                  strategy6,       # PSA-Risk-adaptive : 45-70: No MRI
                  strategy7,       # PSA-Risk-adaptive : 50-60: With MRI
                  strategy8,       # PSA-Risk-adaptive : 50-70: No MRI
                  strategy9,       # DRE only: 45-75: No MRI
                  strategy10A,      # No screening: MRI clinical = FALSE
                  strategy10B      # No screening: MRI clinical = True 
                  )  
# Use set_names to assign your custom names
strategies <- strategies %>%
  set_names(c(
    "strategy1", "strategy2", "strategy3", 
    "strategy4", "strategy5", "strategy6", 
    "strategy7", "strategy8", "strategy9", 
    "strategy10A", "strategy10B"
  ))


## Save the simulations to avoid re-running them later
strategies_10 = list(strategy1,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5,       # PSA-Risk-adaptive : 45-60: With MRI 
                     strategy6,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy7,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy9,       # DRE only: 45-75: No MRI
                     strategy10B      # No screening: MRI clinical = True )
)

d = t(sapply(lapply(strategies, summary),
             function(object) c(object$QALE, object$healthsector.costs)))
d = data.frame(QALE=d[,1], Costs=d[,2],
               labels <- c("strategy1",       # PSA-Risk-adaptive : 45-60: No MRI 
                           "strategy2",       # PSA-Risk-adaptive : 45-70: No MRI
                           "strategy3",       # PSA-Risk-adaptive : 50-60: No MRI
                           "strategy4",       # PSA-Risk-adaptive : 50-70: No MRI
                           "strategy5",       # PSA-Risk-adaptive : 45-60: With MRI 
                           "strategy6",       # PSA-Risk-adaptive : 45-70: With MRI
                           "strategy7",       # PSA-Risk-adaptive : 50-60: With MRI
                           "strategy8",       # PSA-Risk-adaptive : 50-70: With MRI
                           "strategy9",       # DRE only: 45-75: No MRI
                           "strategy10A",     # No screening: MRI clinical = FALSE
                           "strategy10B"),    # No screening: MRI clinical = True )
               pos <- sample(1:4, length(labels), replace = TRUE))


               

with(d, {
  plot(QALE, Costs,
       xlim=c(min(QALE)-0.0002,max(QALE)+0.0009),
       #ylim=c(240,350),
       ylab="Life-time discounted costs (€)",
       xlab="Life-time discounted utilities (QALYs)")
  text(QALE, Costs, labels=labels,pos=pos)
})
with(d[c(11,3,4,8), ], lines(QALE, Costs))

#=======================================================================================================================
##Save the objects for future analysis
#=======================================================================================================================
# Set the timestamp
timestamp <- format(Sys.time(), "%Y-%m-%d")

# Create the file name
file_name <- paste0("..\\Data\\PhD_Monogram_Base_case_strategies_",  n, "_simulations_",timestamp, ".Rdata")


# Save the combined list to the specified file
save(strategies, file = file_name)

#  Predicted outcomes table

# Additional arguments not included in the list
additional_args <- list(from = 45, start_screening = 45, stop_screening = 75)

# Combine the strategy list with the additional arguments
table_args <- c(strategies_10 , additional_args)

table1_with_mri.Base_case  <- do.call(myreport.Fun.A_6_strategies, table_args)

# Save the tables to an Excel file
# Create the file names
file_name_1 <- paste0("../Results_PHD_Monogram/Table_1A_Base_case_10_strategies_", timestamp, ".xlsx")

# Save the table as excel file
write.xlsx(table1_with_mri.Base_case, file = file_name_1)
