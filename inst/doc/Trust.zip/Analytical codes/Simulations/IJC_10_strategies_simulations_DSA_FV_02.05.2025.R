# FILENAME: Deterministic sensitivity analysis simulations
# PROJECT: Cost-effectiveness of prostate cancer screening strategies in Germany: a population-based microsimulation study
# PURPOSE: To perform deterministic sensitivity analysis simulations
# AUTHOR: Trust Muchadeyi adapted from Shuang Hao

# CREATED: 2023-06-01
# LAST UPDATED: 2023-10-14

## R version: R-4.3.1

# Deterministic variations from the base case
## Sensitivity (S1A):    Simulation Using Heijnsdijk  utility estimates instead of PORPUS-U
## Sensitivity (S1B):    Simulation Using EQ-5D utility estimates instead of PORPUS-U
## Sensitivity (S1C):    Simulate using different assumed utilities for SBx and combined TBx

## Sensitivity (S2A):    Simulation with DRE all re-screening after every 4 years
## Sensitivity (S2B):    Simulation with DRE rescreen every 4 years for MRI and biopsy negative groups

## Sensitivity (S3A):    Simulation with PROBASE re-screening after every 5years for MRI, SBx and TBx/SBx negative groups
## Sensitivity (S3B):    Simulation with PROBASE No Re-screening for low  PSA  risk groups: Stop screening =75 for DRE
## Sensitivity (S3C):    Simulation with PROBASE No Re-screening for low PSA risk groups: Stop screening =70 for all
## Sensitivity (S3D):    Simulation with PPROBAS No Re-screening for low risk groups and moderate risk groups and rescreen 2 yearly for high
                         ##risk group up to 70 years
## Sensitivity (S3E):    Simulation with PROBASE No Re-screening for low risk groups Rescreen 5 yearly for moderate 
                         ##risk and high risk group up to 70 years
## Sensitivity (S3F):    Simulation with PROBASE No Re-screening for low risk groups and moderate risk groups

                         ## Rescreen 5 yearly for moderate and high risk group up to 70 years:PSA threshold= 4: Start age 55: Scenario 1
## Sensitivity (S4A):	   Simulation with start screening at 45 and stop screening at 60 for all screening strategies
## Sensitivity (S4B):	   Simulation with start screening at 45 and stop screening at 70 for all screening strategies
## Sensitivity (S4C):    Simulation with start screening at 45 and stop screening at 75 for all screening strategies
## Sensitivity (S5A):    Simulation with start screening at 50 and stop screening at 60 for all screening strategies
## Sensitivity (S5B):    Simulation with start screening at 50 and stop screening at 70 for all screening strategies
## Sensitivity (S5C):    Simulation with start screening at 50 and stop screening at 75 for all screening strategies

## Sensitivity (S6A):     Simulation with start screening at 55 and stop screening at 60 for all screening strategies
## Sensitivity (S6B):     Simulation with start screening at 55 and stop screening at 65 for all screening strategies
## Sensitivity (S6C):     Simulation with start screening at 55 and stop screening at 70 for all screening strategies
## Sensitivity (S6D):     Simulation with start screening at 55 and stop screening at 75 for all screening strategies

## Sensitivity (S7A):     Simulation with start screening at 60 and stop screening at 70 for all screening strategies
## Sensitivity (S7B):     Simulation with start screening at 60 and stop screening at 75 for all screening strategies

## Sensitivity (S8A):     Simulation with Biopsy costs reduced by 50% mainly due to pathology: OBS!Note that Active surveillance costs - with MRI are also affected 
## Sensitivity (S8B):     Simulation with Biopsy costs increased by 50% (mainly due to pathology): OBS!Note that Active surveillance costs - with MRI are also affected
## Sensitivity (S8C):     Simulation with very high cost of Biopsy: 400€

## Sensitivity (S9A):     Simulation by 50% MRI costs (SBx, and SBx/TBx): 50% reduction in biopsy cost: (OBS!Note that Active surveillance costs - with MRI are also affected) 
## Sensitivity (S9B):     Simulation by 150% MRI costs (SBx, and SBx/TBx): 50% increase in biopsy cost:(OBS!Note that Active surveillance costs - with MRI are also affected)
## Sensitivity (S9C):     Simulation an arbitrarily low MRI cost to match with the MRI cost referenced in the EBM code.  (OBS! Note that Active surveillance costs - with MRI are also affected)

## Sensitivity (S10A):    Simulation by 50% PSA lab analysis costs: 50% reduction: (OBS!Note that Active surveillance costs - with MRI are also affected)
## Sensitivity (S10B):    Simulation by 150% PSA lab analysis costs: 50% increase: (OBS!Note that Active surveillance costs - with MRI are also affected)

## Sensitivity (S11A):    Reporting for results using discount rate 5% for both costs and QALYs
## Sensitivity (S12A):    Reporting for results using discount rate 0% for QALYs and 3% for costs
## Sensitivity (S12B):    Reporting for results using discount rate 3% for QALYs and 0% for costs

## Sensitivity (S13A):    Simulation by using re-screening participation rate of 100% for all screening strategies: (OBS! This is Initial screening participation rate = 100%)
## Sensitivity (S13B):    Simulation by using re-screening participation rate of 40% for all screening strategies: (OBS! This is Initial screening participation rate = 80%)

## Sensitivity (S14A):    Simulation by using  first time screening participation rate of 80% for all screening strategies
## Sensitivity (S14B):    Simulation by using  first time screening participation rate of 40% for all screening strategies

## Sensitivity (S15A):    Simulation by using biopsy compliance rate of 100% for all screening strategies
## Sensitivity (S15B):    Simulation by using biopsy compliance rate of 50% for all screening strategies

## Sensitivity (S16A):    Simulation by using reduced ADT+Chemo+HT by 50% for all screening
## Sensitivity (S16B):    Simulation by using increased by ADT+Chemo+HT by 50% for all screening
## Sensitivity (S16C):    Simulation by using increased by ADT+Chemo+HT by 100% for all screening

## Sensitivity (S17):     Simulation using observed treatment from Saarland cancer registry instead of treatment guidelines

## Sensitivity (S18):     Simulation using high biopsy and low MRI cost 

## Sensitivity (S19A):    Simulations with stop screening at 60 for all strategies
## Sensitivity (S19B):    Simulations with stop screening at 70 for all strategies
## Sensitivity (S19C):    Simulations with stop screening at 75 for all strategies
## Sensitivity (S19D):    Simulations with start screening at 50 for all strategies: DRE stop at 70

##Sensitivity (S20):      Simulations with stop screening at 70 for all strategies; Low MRI cost at 120 euros and prevailing Biopsy cost

#=======================================================================================================================
# Set up: OBS!! Run the analysis functions before running this code
#=======================================================================================================================

packages <- c("ggplot2", "plyr", "dplyr", "tidyr", "prostata", "openxlsx", "parallel", "here", "purrr")

# Loop through each package name
for(pkg in packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    # If the package is not installed, install it
    install.packages(pkg)
  }
  # Load the package
  library(pkg, character.only = TRUE)
}
##=======================================================================================================================
#New:Update cost parameters from the previous version
##=======================================================================================================================

modify_ALL_CostParameters <- function(parameters,MRI_diagnostics = FALSE, MRI_active_surveillance = TRUE, DRE = FALSE, scale = 1) {
  
  #if (is.null(MRI_patient)) {
  #stop("MRI_patient is NULL")
  #}
  
  parm <- modifyList(parameters, list(MRI_screen = MRI_diagnostics, DRE = DRE, MRI_active_surveillance = MRI_active_surveillance))
  
  # Modify the cost parameters
  cost_parameters =  c("Invitation" = 0.86+0.86,                                # Invitation letter
                       "Formal PSA" =  4.80 + 20.81,                            # NB! PSA assay and PSA lab analysis only: In the DSA include Consultation fee!!!
                       "Formal panel" =  4.80 + 20.81,                          # Same as Formal PSA: No PSA assay
                       "Opportunistic DRE" = 0.2*21.26+ 0.5*(16.55+13.33),      # Cost for DRE alone: No PSA assay: Factor in that this include CRC 50:50 ratio
                       "Opportunistic PSA" = if (DRE) 4.80+20.81 else (0.2*21.26)+(4.80+20.81)+0.5*(16.55+13.33),
                       "Opportunistic panel" = 4.80 + 20.81,                    # Same as Formal PSA
                       "Biopsy" = 66.64,                                        # Systematic biopsy
                       "MRI" = 500+21.60,                                       # MRI cost
                       "Combined biopsy" = 123.74,                              # Biopsy cost (NB: assumes a preceding MRI)
                       "Assessment" = 131.81,                                   # Urologist consultation
                       "Prostatectomy" = 10927.37,                              # Robot assisted surgery
                       "Radiation therapy" = 8872.83,                           # Radiation therapy
                       "Active surveillance - yearly - w/o MRI"  = if (MRI_active_surveillance) 691.711 else 146.186,   # Urology visit and nurse visit
                       "Active surveillance - yearly - with MRI" = if (MRI_active_surveillance) 691.711 else 146.186,   # Urology visit and nurse visit
                       "ADT+chemo" = 28957.76,                  # Drug treatment for metastasis
                       "Post-Tx follow-up - yearly first" = 207.248,            # Urologist and nurse consultation
                       "Post-Tx follow-up - yearly after" = 76.748,             # PSA test sampling
                       "Palliative therapy - yearly" = 40185.68,                # Palliative care cost
                       "Terminal illness" = 40185.68*0.5                        # Terminal illness cost
  )
  # Add the cost parameters to the parm list
  parm$cost_parameters <- cost_parameters*scale
  
  # Return the modified list
  return(parm)
}
#=======================================================================================================================
cat("\014")   ### Sends a Ctrl+L (form feed) character to the console, clearing it 
cl <- makeCluster(detectCores()-1,type="PSOCK")
n = 1e7                                     

#=======================================================================================================================
## One-way sensitivity (S1A): HSUV set reviewed by Heijnsdijk et.al (2012)
#=======================================================================================================================
# Redefine the utility values to use
utility_estimates_S1A <- c("Invitation" = 1,                    # Heijnsdijk 2012
                           "Formal PSA" = 0.99,                 # Heijnsdijk 2012
                           "Formal panel" = 0.99,               # Heijnsdijk 2012
                           "Opportunistic PSA" = 0.99,          # Heijnsdijk 2012
                           "Opportunistic panel" = 0.99,        # Heijnsdijk 2012
                           "Biopsy" = 0.90,                     # Heijnsdijk 2012
                           "Combined biopsy" = 0.90,            # Heijnsdijk 2012
                           "Cancer diagnosis" = 0.80,           # Heijnsdijk 2012
                           "Prostatectomy part 1" = 0.67,       # Heijnsdijk 2012
                           "Prostatectomy part 2" = 0.77,       # Heijnsdijk 2012
                           "Radiation therapy part 1" = 0.73,   # Heijnsdijk 2012
                           "Radiation therapy part 2" = 0.78,   # Heijnsdijk 2012
                           "Active surveillance" = 0.95,        # Heijnsdijk 2012
                           "Postrecovery period" = 0.95,        # Heijnsdijk 2012
                           "ADT+chemo" = 0.73,                  # Not reported, used 0.73 (measured by EQ-5D)
                           "Palliative therapy" = 0.60,         # Heijnsdijk 2012
                           "Terminal illness" = 0.40,           # Heijnsdijk 2012
                           "Death" = 0.00)

# MRI_diagnostics = TRUE means for PCA suspicious cases are referred to MRI prior biopsy: Default = False
# Note that MRI_clinical = MRI_diagnostics
# Note also that MRI_screen =  MRI_diagnostics
# MRI_patient = True means MRI is used in procedures following PCa confirmations (Treatment, AS  and Treatment FU): Default = TRUE
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE,                # Use of MRI for all symptomatic and or interval cancers  
                                  utility_estimates = utility_estimates_S1A
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S1A = callFhcrc(n, screen="probase",               
                      pop=1950,
                      parm=parm_PSA_noMRI,
                      cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S1A = callFhcrc(n, screen="probase",               
                      pop=1950,
                      parm=modifyList(parm_PSA_noMRI,
                                      list(stop_screening=70)),
                      cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S1A = callFhcrc(n, screen="probase",              
                      pop=1950,
                      parm=modifyList(parm_PSA_noMRI,
                                      list(start_screening=50)),
                      cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S1A = callFhcrc(n, screen="probase",              
                      pop=1950,
                      parm=modifyList(parm_PSA_noMRI,
                                      list(start_screening=50,
                                           stop_screening=70)),
                      cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S1A = callFhcrc(n, screen="probase",            
                      pop=1950,
                      parm=parm_PSA_wMRI,
                      cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S1A = callFhcrc(n, screen="probase",            
                      pop=1950,
                      parm=modifyList(parm_PSA_wMRI,
                                      list(stop_screening=70)),
                      cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S1A = callFhcrc(n, screen="probase",            
                      pop=1950,
                      parm=modifyList(parm_PSA_wMRI,
                                      list(start_screening=50)),
                      cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S1A = callFhcrc(n, screen="probase",            
                      pop=1950,
                      parm=modifyList(parm_PSA_wMRI,
                                      list(start_screening=50,
                                           stop_screening=70)),
                      cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval = 1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval = 1,                # Rescreening for DRE + SBx negative
                                 stop_screening = 75,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S1A = callFhcrc(n, screen="germany_2021",      
                      pop=1950,
                      parm=parm_DRE_only,
                      cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S1A = callFhcrc(n, screen="noScreening",
                        pop=1950,
                        parm=parm_No_screening, 
                        cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S1A = callFhcrc(n, screen="noScreening",
                        pop=1950,
                        parm=parm_No_screening_wMRI_clinical, 
                        cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S1A=list(strategy1.S1A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S1A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S1A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S1A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S1A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S1A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S1A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S1A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S1A,        # DRE only: 45-75: No MRI
                    strategy10A.S1A,      # No screening: MRI clinical = FALSE
                    strategy10B.S1A       # No screening: MRI clinical = True 
                    
)   %>% # package purr in use here
    set_names(strategies_S1A <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
## One-way sensitivity (S1B): EQ5D HSUV set reviewed by Hao et.al (2012)
#=======================================================================================================================
utility_estimates_S1B <-  c("Invitation" = 1,                   # EQ5D based on Hao et al 2021
                            "Formal PSA" = 0.99,                 # EQ5D based on Hao et al 2021
                            "Formal panel" = 0.99,               # EQ5D based on Hao et al 2021
                            "Opportunistic PSA" = 0.99,          # EQ5D based on Hao et al 2021
                            "Opportunistic panel" = 0.99,        # EQ5D based on Hao et al 2021
                            "Biopsy" = 0.90,                     # EQ5D based on Hao et al 2021
                            "Combined biopsy" = 0.90,            # EQ5D based on Hao et al 2021 
                            "Cancer diagnosis" = 0.80,           # EQ5D based on Hao et al 2021
                            "Prostatectomy part 1" = 0.83,       # EQ5D based on Hao et al 2021
                            "Prostatectomy part 2" = 0.89,       # EQ5D based on Hao et al 2021
                            "Radiation therapy part 1" = 0.82,   # EQ5D based on Hao et al 2021
                            "Radiation therapy part 2" = 0.83,   # EQ5D based on Hao et al 2021
                            "Active surveillance" = 0.90,        # EQ5D based on Hao et al 2021
                            "Postrecovery period" = 0.86,        # EQ5D based on Hao et al 2021
                            "ADT+chemo" = 0.73,                  # Not reported, used 0.73 (measured by EQ-5D)
                            "Palliative therapy" = 0.62,         # EQ5D based on Hao et al 2021
                            "Terminal illness" = 0.40,           # Not reported, used Heijnsdijk 2012
                            "Death" = 0.00)
# MRI_diagnostics = TRUE means for PCA suspicious cases are referred to MRI prior biopsy: Default = False
# Note that MRI_clinical = MRI_diagnostics
# Note also that MRI_screen =  MRI_diagnostics
# MRI_patient = True means MRI is used in procedures following PCa confirmations (Treatment, AS  and Treatment FU): Default = TRUE
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold = 3,                   # for referral
                                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening = 60,                # Always 60 for all Probase strategies
                                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation = 0.75,      # Crude assumption
                                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical = FALSE,
                                  MRI_interval = FALSE,                # Use of MRI for all symptomatic and or interval cancers
                                  utility_estimates = utility_estimates_S1B
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S1B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S1B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S1B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S1B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S1B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S1B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S1B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S1B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval = 1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval = 1,                # Rescreening for DRE + SBx negative
                                 stop_screening = 75,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S1B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S1B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S1B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S1B=list(strategy1.S1B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S1B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S1B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S1B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S1B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S1B ,       # PSA-Risk-adaptive : 45-70: With MRI
                    strategy7.S1B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S1B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S1B,        # DRE only: 45-75: No MRI
                    strategy10A.S1B,      # No screening: MRI clinical = FALSE
                    strategy10B.S1B       # No screening: MRI clinical = True
                    
)  %>% # package purr in use here     
   set_names(strategies_S1B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
                          ))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S1C): Use different assumed utilities for  SBx and  combined TBx
#=======================================================================================================================
#=======================================================================================================================
# Redefine the utility values to use
utility_estimates_SBx <- c("Invitation" = 1,                    # Heijnsdijk 2012
                           "Formal PSA" = 0.99,                 # Heijnsdijk 2012
                           "Formal panel" = 0.99,               # Heijnsdijk 2012
                           "Opportunistic PSA" = 0.99,          # Heijnsdijk 2012
                           "Opportunistic panel" = 0.99,        # Heijnsdijk 2012
                           "Biopsy" = 0.85,                     # Assumed < those reported in Heijnsdijk 2012
                           "Combined biopsy" = 0.85,            # Assumed = those reported in Heijnsdijk 2012
                           "Cancer diagnosis" = 0.80,           # EQ5D based on Hao et al 2021
                           "Prostatectomy part 1" = 0.86,       # EQ5D based on Hao et al 2021
                           "Prostatectomy part 2" = 0.95,       # EQ5D based on Hao et al 2021
                           "Radiation therapy part 1" = 0.89,   # EQ5D based on Hao et al 2021
                           "Radiation therapy part 2" = 0.92,   # EQ5D based on Hao et al 2021
                           "Active surveillance" = 0.98,        # EQ5D based on Hao et al 2021
                           "Postrecovery period" = 0.93,        # EQ5D based on Hao et al 2021
                           "ADT+chemo" = 0.80,                  # Not reported, used 0.73 (measured by EQ-5D)
                           "Palliative therapy" = 0.68,         # EQ5D based on Hao et al 2021
                           "Terminal illness" = 0.40,           # Not reported, used Heijnsdijk 2012
                                     "Death" = 0.00)

# MRI_diagnostics = TRUE means for PCA suspicious cases are referred to MRI prior biopsy: Default = False
# Note that MRI_clinical = MRI_diagnostics
# Note also that MRI_screen =  MRI_diagnostics
# MRI_patient = True means MRI is used in procedures following PCa confirmations (Treatment, AS  and Treatment FU): Default = TRUE

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters:
# Set MRI screen = FALSE = MRI_diagnostics
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>%
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE,                # Use of MRI for all symptomatic and or interval cancers
                                  utility_estimates=utility_estimates_SBx
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S1C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S1C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S1C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S1C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI
#=======================================================================================================================
# Redefine the utility values to use
utility_estimates_combined_SBx_TBx <- c("Invitation" = 1,                    # Heijnsdijk 2012
                                        "Formal PSA" = 0.99,                 # Heijnsdijk 2012
                                        "Formal panel" = 0.99,               # Heijnsdijk 2012
                                        "Opportunistic PSA" = 0.99,          # Heijnsdijk 2012
                                        "Opportunistic panel" = 0.99,        # Heijnsdijk 2012
                                        "Biopsy" = 0.90,                     # Assumed = those reported in Heijnsdijk 2012
                                        "Combined biopsy" = 0.90,            # Assumed = those reported in Heijnsdijk 2012
                                        "Cancer diagnosis" = 0.80,           # EQ5D based on Hao et al 2021
                                        "Prostatectomy part 1" = 0.86,       # EQ5D based on Hao et al 2021
                                        "Prostatectomy part 2" = 0.95,       # EQ5D based on Hao et al 2021
                                        "Radiation therapy part 1" = 0.89,   # EQ5D based on Hao et al 2021
                                        "Radiation therapy part 2" = 0.92,   # EQ5D based on Hao et al 2021
                                        "Active surveillance" = 0.98,        # EQ5D based on Hao et al 2021
                                        "Postrecovery period" = 0.93,        # EQ5D based on Hao et al 2021
                                        "ADT+chemo" = 0.80,                  # Not reported, used 0.73 (measured by EQ-5D)
                                        "Palliative therapy" = 0.68,         # EQ5D based on Hao et al 2021
                                        "Terminal illness" = 0.40,           # Not reported, used Heijnsdijk 2012
                                        "Death" = 0.00)
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE,
                                 utility_estimates=utility_estimates_combined_SBx_TBx))                        # Use MRI for all symptomatic and or interval cancers between screening ages
#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S1C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S1C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S1C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S1C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>%
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE,
                                 utility_estimates=utility_estimates_SBx))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S1C = callFhcrc(n, screen="germany_2021",      
                      pop=1950,
                      parm=parm_DRE_only,
                      cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S1C = callFhcrc(n, screen="noScreening",
                        pop=1950,
                        parm=parm_No_screening, 
                        cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S1C = callFhcrc(n, screen="noScreening",
                        pop=1950,
                        parm=parm_No_screening_wMRI_clinical, 
                        cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S1C=list(strategy1.S1C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S1C ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S1C ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S1C ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S1C ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S1C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S1C ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S1C ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S1C,        # DRE only: 45-75: No MRI
                    strategy10A.S1C,      # No screening: MRI clinical = FALSE
                    strategy10B.S1C       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S1C <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S2A): DRE all re-screening after every 4 years 
#=======================================================================================================================
#=======================================================================================================================
# Seems the parameters are not in parm
# if (neg_mri && now()+in->parameter("germany_neg_mri_interval") <= in->parameter("stop_screening"))
# scheduleAt(now() + in->parameter("germany_neg_mri_interval"), toDRE);
# else if (neg_bx && now()+in->parameter("germany_neg_bx_interval") <= in->parameter("stop_screening"))
#   scheduleAt(now() + in->parameter("germany_neg_bx_interval"), toDRE);
# else if (psa < in->parameter("risk_psa_threshold_lower")
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S2A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S2A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S2A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S2A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S2A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S2A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S2A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S2A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=4,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=4,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S2A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S2A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S2A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S2A=list(strategy1.S2A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S2A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S2A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S2A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S2A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S2A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S2A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S2A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S2A,        # DRE only: 45-75: No MRI
                    strategy10A.S2A,      # No screening: MRI clinical = FALSE
                    strategy10B.S2A       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S2A <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S2B): Reduce DRE screening cessation to 70 years
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold = 3,                   # for referral
                                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening = 60,                # Always 60 for all Probase strategies
                                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation = 0.75,      # Crude assumption
                                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical = FALSE,
                                  MRI_interval = FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S2B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S2B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S2B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S2B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S2B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S2B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S2B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S2B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval = 1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval = 1,                # Rescreening for DRE + SBx negative
                                 stop_screening = 70,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S2B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S2B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S2B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S2B=list(strategy1.S2B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S2B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S2B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S2B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S2B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S2B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S2B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S2B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S2B,        # DRE only: 45-75: No MRI
                    strategy10A.S2B,      # No screening: MRI clinical = FALSE
                    strategy10B.S2B       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S2B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
   ))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S3A): PSA-adapted screening: Re-screening after every 5years for MRI, SBx and TBx/SBx negative:
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  germany_neg_mri_interval = 5,     # Rescreening for PSA ≥ 3 ng/ml + PI-RADS 1-2: Now % years
                                  germany_neg_bx_interval = 5,      # Rescreening for PSA ≥ 3 ng/ml + TBx and or SBx negative: Now 5 years
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S3A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S3A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S3A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S3A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S3A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S3A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S3A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S3A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 germany_neg_mri_interval = 4,     # Rescreening for PSA ≥ 3 ng/ml + PI-RADS 1-2: Now % years
                                 germany_neg_bx_interval = 4,      # Rescreening TBx and or SBx negative: Now 4 years
                                 dre_to_biopsy=TRUE))
 
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S3A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S3A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S3A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S3A=list(strategy1.S3A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S3A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S3A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S3A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S3A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S3A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S3A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S3A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S3A,        # DRE only: 45-75: No MRI
                    strategy10A.S3A,      # No screening: MRI clinical = FALSE
                    strategy10B.S3A       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S3A <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S3B): PROBASE No Re-screening for low risk groups
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=50,           # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S3B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S3B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S3B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S3B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S3B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S3B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S3B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S3B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                dre_annual_interval=1,                    # Rescreening for DRE positive
                                germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                stop_screening=75,                        # Always 75 for DRE screening
                                MRI_clinical=FALSE,
                                MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                MRI_screen=FALSE,
                                negbx_to_regular=TRUE,
                                dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S3B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S3B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S3B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S3B=list(strategy1.S3B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S3B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S3B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S3B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S3B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S3B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S3B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S3B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S3B,        # DRE only: 45-75: No MRI
                    strategy10A.S3B,      # No screening: MRI clinical = FALSE
                    strategy10B.S3B       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S3B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S3C): PROBASE No Re-screening for low risk groups: Stop screening = 70 for all age groups
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=50,           # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S3C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S3C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S3C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S3C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S3C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S3C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S3C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S3C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=70,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S3C = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S3C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S3C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S3C=list(strategy1.S3C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S3C ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S3C ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S3C ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S3C ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S3C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S3C ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S3C ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S3C,        # DRE only: 45-75: No MRI
                    strategy10A.S3C,      # No screening: MRI clinical = FALSE
                    strategy10B.S3C       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S3C <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S3D): PSA-risk adaptive: No Re-screening for low risk groups and moderate risk groups
## Rescreen 2 yearly for high risk group up to 70 years
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=50,           # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  germany_neg_mri_interval = 2,     # Rescreening for PSA ≥ 3 ng/ml + PI-RADS 1-2: Now % years
                                  germany_neg_bx_interval = 2,      # Rescreening for PSA ≥ 3 ng/ml + TBx and or SBx negative: Now 5 years
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S3D = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S3D = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S3D = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S3D = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S3D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S3D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S3D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S3D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S3D = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S3D = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S3D = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S3D=list(strategy1.S3D ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S3D ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S3D ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S3D ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S3D ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S3D ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S3D ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S3D ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S3D,        # DRE only: 45-75: No MRI
                    strategy10A.S3D,      # No screening: MRI clinical = FALSE
                    strategy10B.S3D       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S3D <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S3E): PSA-risk adaptive: No Re-screening for low risk groups 
## Rescreen 5 yearly for moderate risk and high risk group up to 70 years
#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=50,           # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=5,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  germany_neg_mri_interval = 5,     # Rescreening for PSA ≥ 3 ng/ml + PI-RADS 1-2: Now % years
                                  germany_neg_bx_interval = 5,      # Rescreening for PSA ≥ 3 ng/ml + TBx and or SBx negative: Now 5 years
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S3E = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S3E = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S3E = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S3E = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S3E = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S3E = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S3E = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S3E = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S3E = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S3E = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S3E = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S3E=list(strategy1.S3E ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S3E ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S3E ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S3E ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S3E ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S3E ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S3E ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S3E ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S3E,        # DRE only: 45-75: No MRI
                    strategy10A.S3E,      # No screening: MRI clinical = FALSE
                    strategy10B.S3E       # No screening: MRI clinical = True 
                    
)   %>% # package purr in use here
    set_names(strategies_S3E <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S3F): PSA-risk adaptive: No Re-screening for low risk groups and moderate risk groups
## Rescreen 5 yearly for moderate and high risk group up to 70 years:PSA threshold= 4: Start age 55: Scenario 1
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=55,               # or 50
                                  psaThreshold=4,                   # for referral
                                  risk_psa_threshold=2,             # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=50,           # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=5,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  germany_neg_mri_interval = 5,     # Rescreening for PSA ≥ 3 ng/ml + PI-RADS 1-2: Now % years
                                  germany_neg_bx_interval = 5,      # Rescreening for PSA ≥ 3 ng/ml + TBx and or SBx negative: Now 5 years
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S3F = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S3F = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S3F = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S3F = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             

#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S3F = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S3F = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S3F = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S3F = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=55,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=70,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))
 
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S3F = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S3F = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S3F = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S3F=list(strategy1.S3F ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S3F ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S3F ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S3F ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S3F ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S3F ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S3F ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S3F ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S3F,        # DRE only: 45-75: No MRI
                    strategy10A.S3F,      # No screening: MRI clinical = FALSE
                    strategy10B.S3F       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S3F <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S4A): Start screening at 45 and Stop screening at 60 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S4A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S4A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S4A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=60)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S4A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=45,
                                               stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S4A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S4A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=60)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S4A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=45)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S4A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=45,
                                               stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=60,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S4A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S4A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S4A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S4A=list(strategy1.S4A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S4A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S4A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S4A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S4A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S4A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S4A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S4A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S4A,        # DRE only: 45-75: No MRI
                    strategy10A.S4A,      # No screening: MRI clinical = FALSE
                    strategy10B.S4A       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S4A <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S4B): Start screening at 45 and Stop screening at 70 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S4B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S4B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S4B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=45)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S4B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=45,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S4B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S4B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S4B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=45)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S4B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=45,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=70,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S4B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S4B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S4B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S4B=list(strategy1.S4B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S4B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S4B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S4B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S4B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S4B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S4B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S4B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S4B,        # DRE only: 45-75: No MRI
                    strategy10A.S4B,      # No screening: MRI clinical = FALSE
                    strategy10B.S4B       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S4B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
## One-way sensitivity (S4C): Start screening at 45 and Stop screening at 75 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=75,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S4C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S4C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S4C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=45)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S4C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=45,
                                               stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S4C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S4C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S4C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=45)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S4C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=45,
                                               stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval = 1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval = 1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening = 75,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S4C = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S4C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S4C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S4C=list(strategy1.S4C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S4C ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S4C ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S4C ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S4C ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S4C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S4C ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S4C ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S4C,        # DRE only: 45-75: No MRI
                    strategy10A.S4C,      # No screening: MRI clinical = FALSE
                    strategy10B.S4C       # No screening: MRI clinical = True 
                    
)   %>% # package purr in use here
    set_names(strategies_S4C <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S5A): Start screening at 50 and Stop screening at 60 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=50,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S5A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S5A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S5A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S5A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S5A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S5A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=60)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S5A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S5A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=60)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=50,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=60,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S5A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S5A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S5A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S5A=list(strategy1.S5A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S5A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S5A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S5A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S5A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S5A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S5A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S5A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S5A,        # DRE only: 45-75: No MRI
                    strategy10A.S5A,      # No screening: MRI clinical = FALSE
                    strategy10B.S5A       # No screening: MRI clinical = True
                    
) %>% # package purr in use here
  set_names(strategies_S5A <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S5B): Start screening at 50 and Stop screening at 70 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=50,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S5B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S5B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S5B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S5B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S5B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S5B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S5B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S5B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=50,                       # Always 45 for DRE screening
                                 dre_annual_interval = 1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval = 1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening = 70,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S5B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S5B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S5B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S5B=list(strategy1.S5B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S5B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S5B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S5B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S5B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S5B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S5B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S5B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S5B,        # DRE only: 45-75: No MRI
                    strategy10A.S5B,      # No screening: MRI clinical = FALSE
                    strategy10B.S5B       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S5B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
## One-way sensitivity (S5C): Start screening at 50 and Stop screening at 75 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=50,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=75,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S5C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S5C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S5C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S5C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S5C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S5C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S5C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S5C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=50,                       # Always 45 for DRE screening
                                 dre_annual_interval = 1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval = 1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening = 75,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S5C = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S5C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S5C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S5C=list(strategy1.S5C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S5C ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S5C ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S5C ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S5C ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S5C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S5C ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S5C ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S5C,        # DRE only: 45-75: No MRI
                    strategy10A.S5C,      # No screening: MRI clinical = FALSE
                    strategy10B.S5C       # No screening: MRI clinical = True
                    
)  %>% # package purr in use here
   set_names(strategies_S5C <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S6A): Start screening at 55 and Stop screening at 60 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=55,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S6A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S6A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S6A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S6A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55,
                                               stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S6A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S6A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=60)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S6A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S6A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55,
                                               stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=55,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=60,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S6A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S6A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S6A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S6A=list(strategy1.S6A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S6A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S6A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S6A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S6A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S6A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S6A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S6A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S6A,        # DRE only: 45-75: No MRI
                    strategy10A.S6A,      # No screening: MRI clinical = FALSE
                    strategy10B.S6A       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S6A <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S6B): Start screening at 55 and Stop screening at 65 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=55,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=65,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S6B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S6B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=65)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S6B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S6B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55,
                                               stop_screening=65)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S6B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S6B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=65)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S6B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S6B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55,
                                               stop_screening=65)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyList(list(start_screening=55,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                  stop_screening=65,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S6B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S6B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S6B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S6B=list(strategy1.S6B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S6B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S6B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S6B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S6B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S6B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S6B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S6B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S6B,        # DRE only: 45-75: No MRI
                    strategy10A.S6B,      # No screening: MRI clinical = FALSE
                    strategy10B.S6B       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S6B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S6C): Start screening at 55 and Stop screening at 70 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=55,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S6C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S6C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S6C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S6C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S6C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S6C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S6C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S6C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyList(list(start_screening=55,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                  stop_screening=70,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S6C = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S6C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S6C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S6C=list(strategy1.S6C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S6C ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S6C ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S6C ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S6C ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S6C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S6C ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S6C ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S6C,        # DRE only: 45-75: No MRI
                    strategy10A.S6C,      # No screening: MRI clinical = FALSE
                    strategy10B.S6C       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S6C <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S6D): Start screening at 55 and Stop screening at 75 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=55,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=75,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S6D = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S6D = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S6D = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S6D = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=55,
                                               stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S6D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S6D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S6D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S6D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=55,
                                               stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyList(list(start_screening=55,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S6D = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S6D = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S6D = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S6D=list(strategy1.S6D ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S6D ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S6D ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S6D ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S6D ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S6D ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S6D ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S6D ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S6D,        # DRE only: 45-75: No MRI
                    strategy10A.S6D,      # No screening: MRI clinical = FALSE
                    strategy10B.S6D       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S6D <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S7A): Start screening at 60 and Stop screening at 70 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=60,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=70,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S7A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S7A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S7A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=60)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S7A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=60,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S7A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S7A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S7A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=60)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S7A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=60,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=60,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=70,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S7A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S7A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S7A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S7A=list(strategy1.S7A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S7A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S7A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S7A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S7A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S7A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S7A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S7A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S7A,        # DRE only: 45-75: No MRI
                    strategy10A.S7A,      # No screening: MRI clinical = FALSE
                    strategy10B.S7A       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
   set_names(strategies_S7A <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S7B): Start screening at 60 and Stop screening at 75 for all screening strategies
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=60,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=75,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
                  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S7B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S7B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S7B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=60)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S7B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=60,
                                               stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S7B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S7B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S7B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=60)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S7B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=60,
                                               stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=60,                       # Always 45 for DRE screening
                                 dre_annual_interval = 1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval = 1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening = 75,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S7B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S7B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S7B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S7B=list(strategy1.S7B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S7B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S7B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S7B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S7B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S7B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S7B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S7B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S7B,        # DRE only: 45-75: No MRI
                    strategy10A.S7B,      # No screening: MRI clinical = FALSE
                    strategy10B.S7B       # No screening: MRI clinical = True 
                    
)   %>% # package purr in use here
    set_names(strategies_S7B <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S8A):Biopsy costs reduce 50%
#=======================================================================================================================
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE) {
  
  Biopsy_cost_S8A <-  0.5*                # Rate of change
    (9.42 +             # Urogenital sonography: EBM 33042
       6.55 +              # Surcharge for transcavitary examination: EBM 
       9.38 +              # Medication (Preventative antibiotics): Updated Kober et al. 2014 using CPI
       19.65) +            # Systematic biopsy including at least 6 punctures and local anaesthesia: EBM 26341
    9.54                # Pathology: EBM19310 # this seems too low, someone to confirm
  
  Combined_biopsy_S8A <-  2*              # Combined biopsy is assume double cost 
    Biopsy_cost_S8A +
    9.54            # Pathology: EBM19310 # this seems too low, someone to confirm
  
  parameters$cost_parameters["Biopsy"] <- Biopsy_cost_S8A
  parameters$cost_parameters["Combined biopsy"]  <- Combined_biopsy_S8A
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 667.446 else 134.053    # NB AS include biopsies so these changes as well, use the separate file to calculate new cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 667.446 else 134.053   # NB AS include biopsies so these changes as well, use the separate file to calculate new cost
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S8A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S8A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S8A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S8A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S8A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S8A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S8A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S8A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S8A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters 
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S8A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S8A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S8A=list(strategy1.S8A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S8A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S8A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S8A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S8A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S8A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S8A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S8A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S8A,        # DRE only: 45-75: No MRI
                    strategy10A.S8A,      # No screening: MRI clinical = FALSE
                    strategy10B.S8A       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
  set_names(strategies_S8A <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S8B):Biopsy costs increased by 50%
#=======================================================================================================================
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE) {
  
  Biopsy_cost_S8B <-  1.5*                 # Rate of change
    (9.42 +              # Urogenital sonography: EBM 33042
       6.55 +              # Surcharge for transcavitary examination: EBM 
       9.38 +              # Medication (Preventative antibiotics): Updated Kober et al. 2014 using CPI
       19.65) +            # Systematic biopsy including at least 6 punctures and local anaesthesia: EBM 26341
    9.54                # Pathology: EBM19310 # this seems too low, someone to confirm
  
  Combined_biopsy_S8B <-  2*              # Combined biopsy is assume double cost 
    Biopsy_cost_S8B +
    9.54            # Pathology: EBM19310 # this seems too low, someone to confirm
  
  parameters$cost_parameters["Biopsy"] <- Biopsy_cost_S8B
  parameters$cost_parameters["Combined biopsy"]  <- Combined_biopsy_S8B
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 715.977 else 158.318    # NB AS include biopsies so these changes as well, use the separate file to calculate new cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 715.977 else 158.31    # NB AS include biopsies so these changes as well, use the separate file to calculate new cost
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S8B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S8B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S8B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S8B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S8B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S8B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S8B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S8B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S8B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S8B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)


parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S8B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S8B=list(strategy1.S8B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S8B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S8B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S8B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S8B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S8B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S8B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S8B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S8B,        # DRE only: 45-75: No MRI
                    strategy10A.S8B,      # No screening: MRI clinical = FALSE
                    strategy10B.S8B       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
  set_names(strategies_S8B <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S8C):Use arbitrary high Standard biopsy cost of cost 400 to reflect high pathology cost
#=======================================================================================================================
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE) {
  
  Biopsy_cost_S8C <-  (9.42 +              # Urogenital sonography: EBM 33042
                         6.55 +              # Surcharge for transcavitary examination: EBM 
                         9.38 +              # Medication (Preventative antibiotics): Updated Kober et al. 2014 using CPI
                         19.65) +            # Systematic biopsy including at least 6 punctures and local anesthesia: EBM 26341
    400                 # Pathology: EBM19310 # this seems too low, someone to confirm
  
  Combined_biopsy_S8C <-  2*                   # Combined biopsy is assume double cost 
    (9.42 +              # Urogenital sonography: EBM 33042
       6.55 +              # Surcharge for transcavitary examination: EBM 
       9.38 +              # Medication (Preventative antibiotics): Updated Kober et al. 2014 using CPI
       19.65) +            # Systematic biopsy including at least 6 punctures and local anesthesia: EBM 26341
    400                 # Pathology: EBM19310 # this seems too low, someone to confirm
  
  parameters$cost_parameters["Biopsy"] <- Biopsy_cost_S8C
  parameters$cost_parameters["Combined biopsy"]  <- Combined_biopsy_S8C
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 857.643 else 312.118  # NB AS include biopsies so these changes as well, use the separate file to calculate new cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 857.643 else 312.118
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S8C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S8C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S8C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S8C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S8C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S8C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S8C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S8C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S8C = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S8C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)


parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S8C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S8C=list(strategy1.S8C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S8C ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S8C ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S8C ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S8C ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S8C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S8C ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S8C ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S8C,        # DRE only: 45-75: No MRI
                    strategy10A.S8C,      # No screening: MRI clinical = FALSE
                    strategy10B.S8C       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
  set_names(strategies_S8C <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S9A):MRI costs reduce 50%
#=======================================================================================================================
#=======================================================================================================================

modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE){
  
  MRI_cost_S9A <- 500*0.5
  
  parameters$cost_parameters["MRI"] <- MRI_cost_S9A
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 441.711 else 146.186    # OBS Take not of the changes in MRI based AS cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 441.711 else 146.186   # OBS Take not of the changes in MRI based AS cost
  ###Need to re look into MRI cost integration here
  return(parameters)
}
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S9A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S9A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S9A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S9A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S9A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S9A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S9A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S9A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S9A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S9A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)


parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S9A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S9A=list(strategy1.S9A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S9A ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S9A ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S9A ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S9A ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S9A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S9A ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S9A ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S9A,        # DRE only: 45-75: No MRI
                    strategy10A.S9A,      # No screening: MRI clinical = FALSE
                    strategy10B.S9A       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
  set_names(strategies_S9A <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S9B):MRI costs increases by 50%
#=======================================================================================================================
#=======================================================================================================================

modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE) {
  
  MRI_cost_S9B <- (500*1.5)+21.60
  
  parameters$cost_parameters["MRI"] <- MRI_cost_S9B
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 941.711 else 146.186    # OBS Take not of the changes in MRI based AS cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 941.711 else 146.186   # OBS Take not of the changes in MRI based AS cost
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S9B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S9B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S9B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S9B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S9B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S9B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S9B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S9B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S9B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>%  
  modifyCostParameters
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S9B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)


parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S9B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S9B=list(strategy1.S9B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S9B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S9B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S9B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S9B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S9B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S9B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S9B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S9B,        # DRE only: 45-75: No MRI
                    strategy10A.S9B,      # No screening: MRI clinical = FALSE
                    strategy10B.S9B       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
  set_names(strategies_S9B <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S9C):MRI reduces to 121.01 referenced by EBM code
#=======================================================================================================================
#=======================================================================================================================

modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE) {
  
  MRI_cost_S9C <- 121.01+21.60
  
  parameters$cost_parameters["MRI"] <- MRI_cost_S9C
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 312.722 else 146.186    # OBS Take not of the changes in MRI based AS cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 312.722 else 146.186   # OBS Take not of the changes in MRI based AS cost
  ###Need to re look into MRI cost integration here
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S9C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S9C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S9C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S9C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S9C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S9C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S9C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S9C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S9C = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S9C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>%                               
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S9C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S9C=list(strategy1.S9C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S9C ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S9C ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S9C ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S9C ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S9C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S9C ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S9C ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S9C,        # DRE only: 45-75: No MRI
                    strategy10A.S9C,      # No screening: MRI clinical = FALSE
                    strategy10B.S9C       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
  set_names(strategies_S9C <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity S10A: PSA costs reduces by 50%
#=======================================================================================================================
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE, DRE=FALSE) {
  
  # PSA test related cost changes 
  parameters$cost_parameters["Opportunistic PSA"] <- if (DRE) 4.80+(0.5*20.81) else (0.2*21.26)+4.80+ (0.5*20.81) +0.5*(16.55+13.33)         # Reduce lab cost by 50%
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 668.041 else 122.516    # OBS Take note of the changes in AS cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 668.041 else 122.516   # OBS Take note of the changes in AS cost
  parameters$cost_parameters["Post-Tx follow-up - yearly first"] <- 165.628                                        # OBS Take note of the changes in Post-Tx cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- 61.326                                  # OBS Take note of the changes in Post-Tx cost
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S10A = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=parm_PSA_noMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S10A = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S10A = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50)),
                           cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S10A = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S10A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=parm_PSA_wMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S10A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S10A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50)),
                           cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S10A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S10A = callFhcrc(n, screen="germany_2021",      
                           pop=1950,
                           parm=parm_DRE_only,
                           cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S10A = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening, 
                             cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S10A = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening_wMRI_clinical, 
                             cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S10A=list(strategy1.S10A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S10A ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S10A ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S10A ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S10A ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S10A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S10A ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S10A ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S10A,        # DRE only: 45-75: No MRI
                     strategy10A.S10A,      # No screening: MRI clinical = FALSE
                     strategy10B.S10A       # No screening: MRI clinical = True 
                     
)   %>% # package purr in use here
  set_names(strategies_S10A <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
  ))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity S10B:PSA costs increases by 50%
#=======================================================================================================================
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE, DRE = FALSE) {
  
  # PSA test related cost changes 
  parameters$cost_parameters["Formal PSA"] <- 4.80+(1.5*20.81)   
  parameters$cost_parameters["Opportunistic PSA"] <- if (DRE) 4.80+(1.5*20.81) else (0.2*21.26)+4.80+ (1.5*20.81) +0.5*(16.55+13.33)         # Reduce lab cost by 50%
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 715.382 else 169.857    # OBS Take note of the changes in AS cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 715.382 else 169.857   # OBS Take note of the changes in AS cost
  parameters$cost_parameters["Post-Tx follow-up - yearly first"] <- 248.868                                        # OBS Take note of the changes in Post-Tx cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- 92.147                                  # OBS Take note of the changes in Post-Tx cost
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S10B = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=parm_PSA_noMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S10B = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S10B = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50)),
                           cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S10B = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S10B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=parm_PSA_wMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S10B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S10B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50)),
                           cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S10B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S10B = callFhcrc(n, screen="germany_2021",      
                           pop=1950,
                           parm=parm_DRE_only,
                           cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                  modifyCostParameters

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S10B = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening, 
                             cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S10B = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening_wMRI_clinical, 
                             cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S10B=list(strategy1.S10B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S10B ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S10B ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S10B ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S10B ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S10B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S10B ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S10B ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S10B,        # DRE only: 45-75: No MRI
                     strategy10A.S10B,      # No screening: MRI clinical = FALSE
                     strategy10B.S10B       # No screening: MRI clinical = True
                     
)  %>% # package purr in use here
  set_names(strategies_S10B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
  ))

#=======================================================================================================================

# S11 and s12  investigate the effect of discount rate.
# The are computed directly in the code for plotting the Tornado plots
#=======================================================================================================================

#=======================================================================================================================

# S11 and s12  investigate the effect of discount rate.
# The are computed directly in the code for plotting the Tornado plots
#=======================================================================================================================


#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S13A): Rescreening participation rate to 100% 
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=1,       # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S13A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S13A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S13A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S13A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S13A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S13A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S13A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S13A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S13A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S13A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S13A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S13A=list(strategy1.S13A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S13A ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S13A ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S13A ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S13A ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S13A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S13A ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S13A ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S13A,        # DRE only: 45-75: No MRI
                     strategy10A.S13A,      # No screening: MRI clinical = FALSE
                     strategy10B.S13A       # No screening: MRI clinical = True
                     
)  %>% # package purr in use here
   set_names(strategies_S13A <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
   ))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S13B): Rescreening participation rate to 80%
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.80,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S13B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S13B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S13B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S13B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S13B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S13B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S13B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S13B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S13B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S13B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S13B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S13B=list(strategy1.S13B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S13B ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S13B ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S13B ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S13B ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S13B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S13B ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S13B ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S13B,        # DRE only: 45-75: No MRI
                     strategy10A.S13B,      # No screening: MRI clinical = FALSE
                     strategy10B.S13B       # No screening: MRI clinical = True 
                    
)   %>% # package purr in use here
    set_names(strategies_S13B <- c("strategy1", "strategy2", "strategy3", 
                                   "strategy4", "strategy5", "strategy6",
                                   "strategy7", "strategy8", "strategy9",
                                   "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S14A): First time screen participation rate to 100% (Formal compliance)
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold = 3,                   # for referral
                                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening = 60,                # Always 60 for all Probase strategies
                                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation = 1,         # Crude assumption
                                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical = FALSE,
                                  MRI_interval = FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S14A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S14A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S14A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S14A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S14A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S14A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S14A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S14A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S14A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S14A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S14A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S14A=list(strategy1.S14A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S14A ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S14A ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S14A ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S14A ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S14A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S14A ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S14A ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S14A,        # DRE only: 45-75: No MRI
                     strategy10A.S14A,      # No screening: MRI clinical = FALSE
                     strategy10B.S14A       # No screening: MRI clinical = True 
                     
)   %>% # package purr in use here
    set_names(strategies_S14A <- c("strategy1", "strategy2", "strategy3", 
                                   "strategy4", "strategy5", "strategy6",
                                   "strategy7", "strategy8", "strategy9",
                                   "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S14B): First time screen participation rate to 50% (Formal compliance)
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.5,         # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S14B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S14B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S14B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S14B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S14B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S14B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S14B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S14B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S14B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S14B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S14B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S14B=list(strategy1.S14B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S14B ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S14B ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S14B ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S14B ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S14B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S14B ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S14B ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S14B,        # DRE only: 45-75: No MRI
                     strategy10A.S14B,      # No screening: MRI clinical = FALSE
                     strategy10B.S14B       # No screening: MRI clinical = True
                     
)   %>% # package purr in use here
    set_names(strategies_S14B <- c("strategy1", "strategy2", "strategy3", 
                                   "strategy4", "strategy5", "strategy6",
                                   "strategy7", "strategy8", "strategy9",
                                   "strategy10A", "strategy10B"
))
#=======================================================================================================================
## One-way sensitivity (S15A): Biopsy compliance 100% 
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=1,               # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S15A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S15A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S15A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S15A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S15A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S15A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S15A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S15A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S15A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S15A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S15A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S15A=list(strategy1.S15A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S15A ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S15A ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S15A ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S15A ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S15A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S15A ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S15A ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S15A,        # DRE only: 45-75: No MRI
                     strategy10A.S15A,      # No screening: MRI clinical = FALSE
                     strategy10B.S15A       # No screening: MRI clinical = True 
                     
)   %>% # package purr in use here
    set_names(strategies_S15A <- c("strategy1", "strategy2", "strategy3", 
                                   "strategy4", "strategy5", "strategy6",
                                   "strategy7", "strategy8", "strategy9",
                                   "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S15B: Biopsy compliance 50% 
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.50,               # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S15B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S15B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S15B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S15B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S15B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S15B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S15B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S15B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S15B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S15B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                             modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S15B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S15B=list(strategy1.S15B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S15B ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S15B ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S15B ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S15B ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S15B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S15B ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S15B ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S15B,        # DRE only: 45-75: No MRI
                     strategy10A.S15B,      # No screening: MRI clinical = FALSE
                     strategy10B.S15B       # No screening: MRI clinical = True
                     
)  %>% # package purr in use here
   set_names(strategies_S15B <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity S16A: mPCa (ADT/Chemo/HT/) reduced by 50%
#=======================================================================================================================
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters) {
  
  parameters$cost_parameters["ADT+chemo"] <- 28957.76 *0.5                          
  return(parameters)
}
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S16A = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=parm_PSA_noMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S16A = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S16A = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50)),
                           cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S16A = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S16A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=parm_PSA_wMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S16A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S16A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50)),
                           cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S16A = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S16A = callFhcrc(n, screen="germany_2021",      
                           pop=1950,
                           parm=parm_DRE_only,
                           cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S16A = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening, 
                             cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S16A = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening_wMRI_clinical, 
                             cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S16A=list(strategy1.S16A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S16A ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S16A ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S16A ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S16A ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S16A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S16A ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S16A ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S16A,        # DRE only: 45-75: No MRI
                     strategy10A.S16A,      # No screening: MRI clinical = FALSE
                     strategy10B.S16A       # No screening: MRI clinical = True 
                     
)   %>% # package purr in use here
  set_names(strategies_S16A <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity S16B: mPCa (ADT/Chemo/HT/) increased by 50%
#=======================================================================================================================
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters) {
  
  # PSA test related cost changes OBS! Mark, I do not understand what Formal Panel and Formal PSA constitute 
  parameters$cost_parameters["ADT+chemo"] <- 28957.76 *1.5
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S16B = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=parm_PSA_noMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S16B = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S16B = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50)),
                           cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S16B = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S16B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=parm_PSA_wMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S16B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S16B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50)),
                           cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S16B = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S16B = callFhcrc(n, screen="germany_2021",      
                           pop=1950,
                           parm=parm_DRE_only,
                           cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S16B = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening, 
                             cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S16B = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening_wMRI_clinical, 
                             cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S16B=list(strategy1.S16B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S16B ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S16B ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S16B ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S16B ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S16B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S16B ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S16B ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S16B,        # DRE only: 45-75: No MRI
                     strategy10A.S16B,      # No screening: MRI clinical = FALSE
                     strategy10B.S16B       # No screening: MRI clinical = True 
                     
)   %>% # package purr in use here
  set_names(strategies_S16B <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
  ))

#=======================================================================================================================
## One-way sensitivity S16C: mPCa (ADT/Chemo/HT/) increased by 100%
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters) {
  
  # PSA test related cost changes OBS! Mark, I do not understand what Formal Panel and Formal PSA constitute 
  parameters$cost_parameters["ADT+chemo"] <- 28957.76 *2
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S16C = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=parm_PSA_noMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S16C = callFhcrc(n, screen="probase",               
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S16C = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50)),
                           cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S16C = callFhcrc(n, screen="probase",              
                           pop=1950,
                           parm=modifyList(parm_PSA_noMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S16C = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=parm_PSA_wMRI,
                           cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S16C = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S16C = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50)),
                           cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S16C = callFhcrc(n, screen="probase",            
                           pop=1950,
                           parm=modifyList(parm_PSA_wMRI,
                                           list(start_screening=50,
                                                stop_screening=70)),
                           cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S16C = callFhcrc(n, screen="germany_2021",      
                           pop=1950,
                           parm=parm_DRE_only,
                           cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S16C = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening, 
                             cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S16C = callFhcrc(n, screen="noScreening",
                             pop=1950,
                             parm=parm_No_screening_wMRI_clinical, 
                             cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S16C=list(strategy1.S16C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S16C ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S16C ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S16C ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S16C ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S16C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S16C ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S16C ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S16C,        # DRE only: 45-75: No MRI
                     strategy10A.S16C,      # No screening: MRI clinical = FALSE
                     strategy10B.S16C       # No screening: MRI clinical = True 
                     
)   %>% # package purr in use here
  set_names(strategies_S16C <- c("strategy1", "strategy2", "strategy3", 
                                 "strategy4", "strategy5", "strategy6",
                                 "strategy7", "strategy8", "strategy9",
                                 "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
  ## One-way sensitivity S17: Change treatment distribution from guidelines to observed
#=======================================================================================================================
#=======================================================================================================================

# German observed treatment distribution informed by Saarland Cancer registry are as follows
parm = prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = TRUE)
parm$prtx = prostata:::germany_observed_tables$prtx                                             # Use this to change treatment distribution from base case  each time 

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold=3,                   # for referral
                                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening=60,                # Always 60 for all Probase strategies
                                  currency_rate =1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation=0.75,      # Crude assumption
                                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical =FALSE,
                                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
parm_PSA_noMRI$prtx = prostata:::germany_observed_tables$prtx
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S17A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S17A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S17A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S17A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S17A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S17A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S17A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S17A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interval=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                                 stop_screening=75,                        # Always 75 for DRE screening
                                 MRI_clinical=FALSE,
                                 MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen=FALSE,
                                 negbx_to_regular=TRUE,
                                 dre_to_biopsy=TRUE))
parm_DRE_only$prtx = prostata:::germany_observed_tables$prtx
#=======================================================================================================================
#Strategy VII: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S17A = callFhcrc(n, screen="germany_2021",      
                           pop=1950,
                           parm=parm_DRE_only,
                           cl=cl)

#=======================================================================================================================
# Strategy VI: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 
parm_No_screening$prtx = prostata:::germany_observed_tables$prtx
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S17A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine
parm_No_screening_wMRI_clinical$prtx = prostata:::germany_observed_tables$prtx
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S17A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S17A=list(strategy1.S17A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S17A ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S17A ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S17A ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S17A ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S17A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S17A ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S17A ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S17A,        # DRE only: 45-75: No MRI
                     strategy10A.S17A,      # No screening: MRI clinical = FALSE
                     strategy10B.S17A       # No screening: MRI clinical = True
                     
)  %>% # package purr in use here
   set_names(strategies_S17A <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
))

#=======================================================================================================================
## One-way sensitivity (S18):Use arbitrary high Standard biopsy cost of cost 400 to reflect high pathology cost and low MRI cost of 121 reflected in the EBM code
#=======================================================================================================================

# Define the function to modify certain cost parameters
modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE) {
  
  Biopsy_cost_S18 <-  (9.42 +                       # Urogenital sonography: EBM 33042
                         6.55 +                     # Surcharge for transcavitary examination: EBM 
                         9.38 +                     # Medication (Preventative antibiotics): Updated Kober et al. 2014 using CPI
                         19.65) +                   # Systematic biopsy including at least 6 punctures and local anesthesia: EBM 26341
    400                        # Pathology: EBM19310 # this seems too low, someone to confirm
  
  Combined_biopsy_S18 <-  2*                   # Combined biopsy is assume double cost 
    (9.42 +              # Urogenital sonography: EBM 33042
       6.55 +              # Surcharge for transcavitary examination: EBM 
       9.38 +              # Medication (Preventative antibiotics): Updated Kober et al. 2014 using CPI
       19.65) +            # Systematic biopsy including at least 6 punctures and local anesthesia: EBM 26341
    400                 # Pathology: EBM19310 # this seems too low, someone to confirm
  
  MRI_cost_S9C <- 121.01+21.60
  
  parameters$cost_parameters["Biopsy"] <- Biopsy_cost_S18
  parameters$cost_parameters["Combined biopsy"]  <- Combined_biopsy_S18
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 478.653 else 312.117  # NB AS include biopsies so these changes as well, use the separate file to calculate new cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance)478.653 else 312.117 
  return(parameters)
}

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S18 = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S18 = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S18 = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S18 = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S18 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S18 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S18 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S18 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S18 = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S18 = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S18 = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S18=list(strategy1.S18 ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S18 ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S18 ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S18 ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S18 ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S18 ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S18 ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S18 ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S18,        # DRE only: 45-75: No MRI
                    strategy10A.S18,      # No screening: MRI clinical = FALSE
                    strategy10B.S18       # No screening: MRI clinical = True 
                    
)  %>% # package purr in use here
  set_names(strategies_S18 <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6", 
                                "strategy7", "strategy8", "strategy9", 
                                "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S19A): Stop screening at 60 for all strategies
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold = 3,                   # for referral
                                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening = 60,                # Always 60 for all Probase strategies
                                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation = 0.75,      # Crude assumption
                                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical = FALSE,
                                  MRI_interval = FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S19A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S19A = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S19A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S19A = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=60)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S19A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S19A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=60)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S19A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S19A = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=60)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                                 dre_annual_interva=1,                    # Rescreening for DRE positive
                                 germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                                 stop_screening=60,                        # Always 75 for DRE screening
                                 MRI_clinical = FALSE,
                                 MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                                 MRI_screen = FALSE,
                                 negbx_to_regular = TRUE,
                                 dre_to_biopsy = TRUE))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S19A = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S19A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S19A = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S19A=list(strategy1.S19A ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S19A ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S19A ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S19A ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S19A ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S19A ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S19A ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S19A ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S19A,        # DRE only: 45-75: No MRI
                     strategy10A.S19A,      # No screening: MRI clinical = FALSE
                     strategy10B.S19A       # No screening: MRI clinical = True 
                     
)  %>% # package purr in use here
   set_names(strategies_S19A <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S19B): Stop screening at 70 for all strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening = 45,               # or 50
                                  psaThreshold = 3,                   # for referral
                                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening = 70,                # Always 60 for all Probase strategies
                                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation = 0.75,      # Crude assumption
                                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical = FALSE,
                                  MRI_interval = FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S19B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S19B = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S19B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S19B = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S19B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S19B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S19B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S19B = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval = 1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval = 1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                  stop_screening=70,                        # Always 75 for DRE screening
                  MRI_clinical = FALSE,
                  MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen = FALSE,
                  negbx_to_regular = TRUE,
                  dre_to_biopsy = TRUE))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S19B = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S19B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S19B = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S19B=list(strategy1.S19B ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S19B ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S19B ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S19B ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S19B ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S19B ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S19B ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S19B ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S19B,        # DRE only: 45-75: No MRI stop_screening=70
                    strategy10A.S19B,      # No screening: MRI clinical = FALSE
                    strategy10B.S19B       # No screening: MRI clinical = True 
                    
)   %>% # package purr in use here
    set_names(strategies_S19B <- c("strategy1", "strategy2", "strategy3", 
                                   "strategy4", "strategy5", "strategy6",
                                   "strategy7", "strategy8", "strategy9",
                                   "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S19C): Stop screening at 75 for all strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=45,               # or 50
                                  psaThreshold = 3,                   # for referral
                                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening = 75,                # Always 60 for all Probase strategies
                                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation = 0.75,      # Crude assumption
                                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical = FALSE,
                                  MRI_interval = FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S19C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S19C = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S19C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S19C = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=75)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S19C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S19C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S19C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S19C = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=75)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval = 1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval = 1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical = FALSE,
                  MRI_interval = FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen = FALSE,
                  negbx_to_regular = TRUE,
                  dre_to_biopsy = TRUE))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S19C = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S19C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S19C = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S19C=list(strategy1.S19C ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S19C ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S19C ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S19C ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S19C ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S19C ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S19C ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S19C ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S19C,        # DRE only: 45-75: No MRIstop_screening=70
                     strategy10A.S19C,      # No screening: MRI clinical = FALSE
                     strategy10B.S19C       # No screening: MRI clinical = True 
                     
)  %>% # package purr in use here
   set_names(strategies_S19C <- c("strategy1", "strategy2", "strategy3", 
                                  "strategy4", "strategy5", "strategy6",
                                  "strategy7", "strategy8", "strategy9",
                                  "strategy10A", "strategy10B"
))
#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S19D): Start screening at 50 for all strategies
#=======================================================================================================================
#=======================================================================================================================


#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
                  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
                  modifyList(list(start_screening=50,               # or 50
                                  psaThreshold = 3,                   # for referral
                                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                                  stop_screening = 60,                # Always 60 for all Probase strategies
                                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                                  screeningParticipation = 0.75,      # Crude assumption
                                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                                  MRI_clinical = FALSE,
                                  MRI_interval = FALSE                # Use of MRI for all symptomatic and or interval cancers
                  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S19D = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S19D = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S19D = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S19D = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S19D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S19D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S19D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S19D = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
                 modifyList(list(start_screening=50,                  # Always 45 for DRE screening
                            dre_annual_interval=1,                    # Rescreening for DRE positive
                            germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                            stop_screening=70,                        # Always 75 for DRE screening
                            MRI_clinical=FALSE,
                            MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                            MRI_screen=FALSE,
                            negbx_to_regular=TRUE,
                            dre_to_biopsy=TRUE))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S19D = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S19D = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
                                modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S19D = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S19D=list(strategy1.S19D ,       # PSA-Risk-adaptive : 45-60: No MRI 
                     strategy2.S19D ,       # PSA-Risk-adaptive : 45-70: No MRI
                     strategy3.S19D ,       # PSA-Risk-adaptive : 50-60: No MRI
                     strategy4.S19D ,       # PSA-Risk-adaptive : 50-70: No MRI
                     strategy5.S19D ,       # PSA-Risk-adaptive : 45-60: With MRI
                     strategy6.S19D ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                     strategy7.S19D ,       # PSA-Risk-adaptive : 50-60: With MRI
                     strategy8.S19D ,       # PSA-Risk-adaptive : 50-70: With MRI
                     strategy9.S19D,        # DRE only: 45-75: No MRI
                     strategy10A.S19D,      # No screening: MRI clinical = FALSE
                     strategy10B.S19D       # No screening: MRI clinical = True 
                     
)   %>% # package purr in use here
    set_names(strategies_S19D <- c("strategy1", "strategy2", "strategy3", 
                                   "strategy4", "strategy5", "strategy6",
                                   "strategy7", "strategy8", "strategy9",
                                   "strategy10A", "strategy10B"
))

#=======================================================================================================================
#=======================================================================================================================
## One-way sensitivity (S20): Scenario 3: Stop screening at 70 for all strategies; Low MRI cost at 120 euros and prevailing Biopsy cost
#=======================================================================================================================
#=======================================================================================================================

modifyCostParameters <- function(parameters, MRI_active_surveillance = TRUE) {
  
  MRI_cost_S9C <- 121.01+21.60
  
  parameters$cost_parameters["MRI"] <- MRI_cost_S9C
  parameters$cost_parameters["Active surveillance - yearly - w/o MRI"] <- if (MRI_active_surveillance) 312.722 else 146.186    # OBS Take not of the changes in MRI based AS cost
  parameters$cost_parameters["Active surveillance - yearly - with MRI"] <- if (MRI_active_surveillance) 312.722 else 146.186   # OBS Take not of the changes in MRI based AS cost
  ###Need to re look into MRI cost integration here
  return(parameters)
}
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold = 3,                   # for referral
                  risk_psa_threshold = 1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3
                  risk_lower_interval = 5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval = 2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening = 70,                # Always 60 for all Probase strategies
                  currency_rate = 1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance = TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation = 0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation = 0.75,      # Crude assumption
                  biopsyCompliance = 0.65,            # Default is 0.856 based on a previous ESPRC study
                  negbx_to_regular = TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical = FALSE,
                  MRI_interval = FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S20 = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=parm_PSA_noMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S20 = callFhcrc(n, screen="probase",               
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S20 = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50)),
                          cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S20 = callFhcrc(n, screen="probase",              
                          pop=1950,
                          parm=modifyList(parm_PSA_noMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S20 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=parm_PSA_wMRI,
                          cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S20 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S20 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50)),
                          cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S20 = callFhcrc(n, screen="probase",            
                          pop=1950,
                          parm=modifyList(parm_PSA_wMRI,
                                          list(start_screening=50,
                                               stop_screening=70)),
                          cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + PSA ≥ 4 ng/ml + TBx and or SBx negative
                  stop_screening=70,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))
#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S20 = callFhcrc(n, screen="germany_2021",      
                          pop=1950,
                          parm=parm_DRE_only,
                          cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S20 = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening, 
                            cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyCostParameters %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S20 = callFhcrc(n, screen="noScreening",
                            pop=1950,
                            parm=parm_No_screening_wMRI_clinical, 
                            cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S20=list(strategy1.S20 ,       # PSA-Risk-adaptive : 45-60: No MRI 
                    strategy2.S20 ,       # PSA-Risk-adaptive : 45-70: No MRI
                    strategy3.S20 ,       # PSA-Risk-adaptive : 50-60: No MRI
                    strategy4.S20 ,       # PSA-Risk-adaptive : 50-70: No MRI
                    strategy5.S20 ,       # PSA-Risk-adaptive : 45-60: With MRI
                    strategy6.S20 ,       # PSA-Risk-adaptive : 45-70: Wit MRI
                    strategy7.S20 ,       # PSA-Risk-adaptive : 50-60: With MRI
                    strategy8.S20 ,       # PSA-Risk-adaptive : 50-70: With MRI
                    strategy9.S20,        # DRE only: 45-75: No MRI
                    strategy10A.S20,      # No screening: MRI clinical = FALSE
                    strategy10B.S20       # No screening: MRI clinical = True 
                    
)   %>% # package purr in use here
  set_names(strategies_S20 <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
## One-way sensitivity (S21): PSA-risk adaptive:Rescreening interval of 1 for moderate risk groups and 2 for low risk groups
#=======================================================================================================================
#=======================================================================================================================

#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=3,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=2,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=1,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )
#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S21 = callFhcrc(n, screen="probase",               
                         pop=1950,
                         parm=parm_PSA_noMRI,
                         cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S21 = callFhcrc(n, screen="probase",               
                         pop=1950,
                         parm=modifyList(parm_PSA_noMRI,
                                         list(stop_screening=70)),
                         cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S21 = callFhcrc(n, screen="probase",              
                         pop=1950,
                         parm=modifyList(parm_PSA_noMRI,
                                         list(start_screening=50)),
                         cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S21 = callFhcrc(n, screen="probase",              
                         pop=1950,
                         parm=modifyList(parm_PSA_noMRI,
                                         list(start_screening=50,
                                              stop_screening=70)),
                         cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S21 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=parm_PSA_wMRI,
                         cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S21 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=modifyList(parm_PSA_wMRI,
                                         list(stop_screening=70)),
                         cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S21 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=modifyList(parm_PSA_wMRI,
                                         list(start_screening=50)),
                         cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S21 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=modifyList(parm_PSA_wMRI,
                                         list(start_screening=50,
                                              stop_screening=70)),
                         cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S21 = callFhcrc(n, screen="germany_2021",      
                         pop=1950,
                         parm=parm_DRE_only,
                         cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S21 = callFhcrc(n, screen="noScreening",
                           pop=1950,
                           parm=parm_No_screening, 
                           cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S21 = callFhcrc(n, screen="noScreening",
                           pop=1950,
                           parm=parm_No_screening_wMRI_clinical, 
                           cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S21 = list(strategy1.S21 ,       # PSA-Risk-adaptive : 45-60: No MRI 
                      strategy2.S21 ,       # PSA-Risk-adaptive : 45-70: No MRI
                      strategy3.S21 ,       # PSA-Risk-adaptive : 50-60: No MRI
                      strategy4.S21 ,       # PSA-Risk-adaptive : 50-70: No MRI
                      strategy5.S21 ,       # PSA-Risk-adaptive : 45-60: With MRI
                      strategy6.S21 ,       # PSA-Risk-adaptive : 45-70: No MRI
                      strategy7.S21 ,       # PSA-Risk-adaptive : 50-60: With MRI
                      strategy8.S21 ,       # PSA-Risk-adaptive : 50-70: No MRI
                      strategy9.S21 ,       # DRE only: 45-75: No MRI
                      strategy10A.S21 ,      # No screening: MRI clinical = FALSE
                      strategy10B.S21       # No screening: MRI clinical = True
                      
)   %>% # package purr in use here
  set_names(strategies_S21 <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))

#=======================================================================================================================
## One-way sensitivity (S22): PSA Threshold of 4
#=======================================================================================================================
#=======================================================================================================================
#Group 1: PSA-Risk-adaptive : No MRI
#=======================================================================================================================
# Initialize parameters and update cost parameters and modify selected other input parameters: 
# Set MRI screen = FALSE = MRI_diagnostics 
parm_PSA_noMRI <- prostata:::TrustParameters(MRI_diagnostics = FALSE, DRE = FALSE) %>% 
  modify_ALL_CostParameters(scale = 1) %>%          # Remember this call also modify list with MRI_screen = MRI_diagnostics and DRE = DRE
  modifyList(list(start_screening=45,               # or 50
                  psaThreshold=4,                   # for referral
                  risk_psa_threshold=1.5,           # Rescreening threshold for PSA < 1.5 ng/ml or greater to 3 
                  risk_lower_interval=5,            # Rescreening for PSA < 1.5 ng/ml
                  risk_upper_interval=2,            # Rescreening for 1.5 ng/ml <PSA < 3 ng/ml
                  stop_screening=60,                # Always 60 for all Probase strategies
                  currency_rate =1,                 # OBS!! Do this for all the simulation
                  use_biopsyCompliance=TRUE,        # Keep this TRUE for all strategies, including No screening
                  rescreeningParticipation=0.95,    # Based on based on a previous ESPRC study
                  screeningParticipation=0.75,      # Crude assumption
                  biopsyCompliance=0.65,            # Default is 0.856 based on a previous ESPRC study 
                  negbx_to_regular=TRUE,            # Flag for whether to return to regular screening after a negative biopsy
                  MRI_clinical =FALSE,
                  MRI_interval=FALSE                # Use of MRI for all symptomatic and or interval cancers  
  )
  )

#=======================================================================================================================
# Strategy I: PSA-Risk-adaptive: 45-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy1.S22 = callFhcrc(n, screen="probase",               
                         pop=1950,
                         parm=parm_PSA_noMRI,
                         cl=cl)

#=======================================================================================================================
# Strategy II: PSA-Risk-adaptive: 45-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy2.S22 = callFhcrc(n, screen="probase",               
                         pop=1950,
                         parm=modifyList(parm_PSA_noMRI,
                                         list(stop_screening=70)),
                         cl=cl)

#=======================================================================================================================
# Strategy III: PSA-Risk-adaptive: 50-60: No MRI
#=======================================================================================================================
set.seed(12345)
strategy3.S22 = callFhcrc(n, screen="probase",              
                         pop=1950,
                         parm=modifyList(parm_PSA_noMRI,
                                         list(start_screening=50)),
                         cl=cl)

#=======================================================================================================================
# Strategy IV: PSA-Risk-adaptive: 50-70: No MRI
#=======================================================================================================================
set.seed(12345)
strategy4.S22 = callFhcrc(n, screen="probase",              
                         pop=1950,
                         parm=modifyList(parm_PSA_noMRI,
                                         list(start_screening=50,
                                              stop_screening=70)),
                         cl=cl)

#=======================================================================================================================
# #Group 2: PSA-Risk-adaptive : with MRI 
#=======================================================================================================================
parm_PSA_wMRI <- modifyList(parm_PSA_noMRI,                         
                            list(MRI_screen=TRUE,
                                 MRI_interval=TRUE))                        # Use MRI for all symptomatic and or interval cancers between screening ages             



#=======================================================================================================================
# Strategy V: PSA-Risk-adaptive : 45-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy5.S22 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=parm_PSA_wMRI,
                         cl=cl)

#=======================================================================================================================
# Strategy VI: PSA-Risk-adaptive : 45-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy6.S22 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=modifyList(parm_PSA_wMRI,
                                         list(stop_screening=70)),
                         cl=cl)
#=======================================================================================================================
# Strategy VII: PSA-Risk-adaptive : 50-60: With MRI
#=======================================================================================================================
set.seed(12345)
strategy7.S22 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=modifyList(parm_PSA_wMRI,
                                         list(start_screening=50)),
                         cl=cl)
#=======================================================================================================================
# Strategy VIII: PSA-Risk-adaptive : 50-70: With MRI
#=======================================================================================================================
set.seed(12345)
strategy8.S22 = callFhcrc(n, screen="probase",            
                         pop=1950,
                         parm=modifyList(parm_PSA_wMRI,
                                         list(start_screening=50,
                                              stop_screening=70)),
                         cl=cl)
#=======================================================================================================================
#Group 3: DRE only
#=======================================================================================================================
parm_DRE_only <- modify_ALL_CostParameters(parm_PSA_wMRI,DRE=TRUE, MRI_diagnostics = TRUE, scale = 1) %>% 
  modifyList(list(start_screening=45,                       # Always 45 for DRE screening
                  dre_annual_interval=1,                    # Rescreening for DRE positive
                  germany_neg_bx_interval=1,                # Rescreening for DRE + SBx negative 
                  stop_screening=75,                        # Always 75 for DRE screening
                  MRI_clinical=FALSE,
                  MRI_interval=FALSE,                       # Use of MRI for all symptomatic and or interval cancers
                  MRI_screen=FALSE,
                  negbx_to_regular=TRUE,
                  dre_to_biopsy=TRUE))

#=======================================================================================================================
#Strategy IX: DRE Only: No PSA no MRI
#=======================================================================================================================
# Guidelines or practice
set.seed(12345)
strategy9.S22 = callFhcrc(n, screen="germany_2021",      
                         pop=1950,
                         parm=parm_DRE_only,
                         cl=cl)

#=======================================================================================================================
# Strategy X: No screening with  or without MRI diagnostics 
#=======================================================================================================================
# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
parm_No_screening=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) 

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10A.S22 = callFhcrc(n, screen="noScreening",
                           pop=1950,
                           parm=parm_No_screening, 
                           cl=cl)

parm_No_screening_wMRI_clinical=modify_ALL_CostParameters(parm_DRE_only, DRE=FALSE, MRI_diagnostics = FALSE, scale = 1) %>% 
  modifyList(list(MRI_clinical=TRUE))              # Use of MRI for all symptomatic cancers: Current routine

# Note that with the setting in Strategy VI, there is no MRI diagnostics = False as well here
# Note that MRI_treatment = TRUE is still the setting
set.seed(12345)
strategy10B.S22 = callFhcrc(n, screen="noScreening",
                           pop=1950,
                           parm=parm_No_screening_wMRI_clinical, 
                           cl=cl)

## Save the simulations to avoid re-running them later 
strategies_S22 = list(strategy1.S22 ,       # PSA-Risk-adaptive : 45-60: No MRI 
                      strategy2.S22 ,       # PSA-Risk-adaptive : 45-70: No MRI
                      strategy3.S22 ,       # PSA-Risk-adaptive : 50-60: No MRI
                      strategy4.S22 ,       # PSA-Risk-adaptive : 50-70: No MRI
                      strategy5.S22 ,       # PSA-Risk-adaptive : 45-60: With MRI
                      strategy6.S22 ,       # PSA-Risk-adaptive : 45-70: No MRI
                      strategy7.S22 ,       # PSA-Risk-adaptive : 50-60: With MRI
                      strategy8.S22 ,       # PSA-Risk-adaptive : 50-70: No MRI
                      strategy9.S22 ,       # DRE only: 45-75: No MRI
                      strategy10A.S22 ,      # No screening: MRI clinical = FALSE
                      strategy10B.S22       # No screening: MRI clinical = True
                     
)   %>% # package purr in use here
  set_names(strategies_S22 <- c("strategy1", "strategy2", "strategy3", 
                                "strategy4", "strategy5", "strategy6",
                                "strategy7", "strategy8", "strategy9",
                                "strategy10A", "strategy10B"
  ))
#=======================================================================================================================
#  Saving the whole simulations
#=======================================================================================================================

# Find all objects in the global environment that start with "strategies_S"
strategy_names <- ls(pattern = "^strategies_S")

# Custom sort to handle numeric parts properly
strategy_names <- strategy_names[order(
  as.numeric(gsub(".*_S([0-9]+).*", "\\1", strategy_names)),  # Extract numeric part after "S"
  strategy_names                                              # Sort alphabetically within the same number
)]

# Retrieve objects in the sorted order
all_DSA_strategy_list <- mget(strategy_names)

# Generate the timestamp and file name
timestamp <- format(Sys.time(), "%Y-%m-%d")  # Convert timestamp to "YYYY-MM-DD" format
file_name <- paste0("..\\Data\\IJC_monogram_DSA_Ten_strategies_FV_FV_", timestamp, ".Rdata")

# Save the combined list to the specified file
save(all_DSA_strategy_list, file = file_name)

# Print a confirmation message
message("Combined strategies saved to: ", file_name)
names(all_DSA_strategy_list)
#==========================The END========================================================================================