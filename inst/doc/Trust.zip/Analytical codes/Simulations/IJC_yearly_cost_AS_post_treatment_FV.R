## =======================================================================================================================
## FILENAME: Trust.R
## PROJECT: cost-effectiveness of prostate cancer screening in German
## PURPOSE: To calculate yearly cost for AS and post treatment
## AUTHOR: Trust Muchadeyi

# CREATED: 2023-09-24
# LAST UPDATED: 2023-09-30

## R version: R-4.3.1


library(openxlsx)
library(tidyverse)
library(dplyr)

#=======================================================================================================================
# Calculate yearly cost estimates for Active surveillance to use later in the function
#=======================================================================================================================
# S3 guidelines : 
# The tumour should be checked every three months during the first two years by PSA determination and DRU:
# If the PSA value remains stable, the tumour should be examined every 6 months thereafter
# Biopsies should be taken every twelve to 18 months for the first three years, and later every three years if the findings are stable
# We modelled Biopsy once every year for 2 years then after every 3 years to match with tumour checking 

# 1. Active surveillance - yearly - w/o MRI

cost_per_year_first_year    <-  # Consultation fees
                                21.26*4*0.2 +                    # Basic flat rate per insured person per quarter: EBM (26211 + EBM26212)/2 (OBS! 0.2 to account for multiple services) 
                                21.95*4 +                        # Additional flat rate oncology
  
                                # PSA sampling
                                4.80*4 +                         # PSA sampling
                                20.81*4 +                        # PSA analysis
  
                                # Standard biopsy cost
                                21.26 +                          # Specialist consultation : Basic flat rate per insured person per quarter: EBM 26211 and 26212 (OBS: Double counting here!!)               
                                9.64 +                           # Urogenital sonography :EBM 19310
                                19.65 +                          # Systematic biopsy: EBM 26341+         
                                6.55 +                           # Surcharge for transcavitary examination
                                9.54                             # Pathology of biopsy 

cost_per_year_second_year <-  cost_per_year_first_year


# Then standard biopsy should be taken every 3 years after the first year 

yearly_recurring_cost_after_2_years <- # consultation fees
                                       21.26*2*0.2 +                    # Basic flat rate per insured person per quarter: EBM (26211 + EBM26212)/2 (OBS! 0.2 to account for multiple services) 
                                       21.95*2 +                        # Additional flat rate oncology 
                                      
                                       # PSA sampling
                                       4.80*2 +                         # PSA sampling
                                       20.81*2 +                        # PSA analysis
  
                                       # Standard biopsy
                                       1/3*                             # A biopsy should be taken every 3 years after the first year
                                       (21.26+                          # Specialist consultation : Basic flat rate per insured person per quarter: EBM 26211 and 26212                
                                       9.64 +                           # Urogenital sonography :EBM 19310
                                       19.65 +                          # Systematic biopsy: EBM 26341+         
                                       6.55 +                           # Surcharge for transcavitary examination +         # Calculated at the beginning: only including urogenital sonography and punching
                                       #121.01 +                        # MRI guiding (NB: assumes a preceding MRI)
                                       9.54)                            # Pathology of biopsy

est_remaining_life <- 14.55120537                                       # Estimated remaining life at median age at diagnosis from German life tables

sum_cost_remaining_life <- cost_per_year_first_year + cost_per_year_second_year + ((est_remaining_life-2)*yearly_recurring_cost_after_2_years)

new_cost_without_MRI <-  sum_cost_remaining_life/est_remaining_life           


# 2. Active surveillance - yearly - with MRI (OBS! Combined biopsy is used with MRI)
cost_per_year_first_year_wMRI    <- # consultation fees
                                    21.26*4*0.2 +               # Basic flat rate per insured person per quarter: EBM (26211 + EBM26212)/2 (OBs! 0.2 to account for multiple services)  
                                    21.95*4 +                   # Additional flat rate oncology 
  
                                    # PSA sampling 
                                    4.80*4 +                    # PSA sampling
                                    20.81*4 +                   # PSA analysis

                                    # MRI
                                    21.26 +                           # Consultation costs based on Basic flat rate per insured person per quarter: EBM 26211 and 26212
                                    250+                             # EBM 3442    (OBS! how is this coded? For example is it only for triaging such that I need to include it for combined biopsy and AS cost)
                                    
                                    #Combined biopsy
                                    (2*                               # Combined biopsy assumed double the cost of standard biopsy
                                    (21.26+                           # Specialist consultation : Basic flat rate per insured person per quarter: EBM 26211 and 26212                
                                     9.64 +                           # Urogenital sonography :EBM 19310
                                     19.65 +                          # Systematic biopsy: EBM 26341+         
                                     6.55) +                          # Surcharge for transcavitary examination +         # Calculated at the beginning: only including urogenital sonography and punching
                                     #121.01 +                        # MRI guiding (NB: assumes a preceding MRI)
                                     9.54)                            # Pathology of biopsy

cost_per_year_second_year_wMRI <- cost_per_year_first_year_wMRI


# Then combined biopsy should be taken every 3 years after the first year 

yearly_recurring_cost_after_2_years_wMRI <- # consultation fees
                                       21.26*2*0.2 +                    # Basic flat rate per insured person per quarter: EBM (26211 + EBM26212)/2 (OBS! 0.2 to account for multiple services) 
                                       21.95*2 +                        # Additional flat rate oncology 
                                      
                                       # PSA sampling
                                       4.80*2 +                         # PSA sampling
                                       20.81*2 +                        # PSA analysis
                                      
                                       # MRI
                                       21.26 +                          # Consultation costs based on Basic flat rate per insured person per quarter: EBM 26211 and 26212
                                       250+                            # EBM 3442    (OBS! how is this coded? For example is it only for triaging such that I need to include it for combined biopsy and AS cost)
                                      
                                       #Combined biopsy
                                       1/3*                             # A biopsy should be taken every 3 years after the first year
                                       (2*
                                       (21.26+                          # Specialist consultation : Basic flat rate per insured person per quarter: EBM 26211 and 26212                
                                       9.64 +                           # Uro-genital sonography :EBM 19310
                                       19.65 +                          # Systematic biopsy: EBM 26341+         
                                       6.55) +                          # Surcharge for transcavitary examination +         # Calculated at the beginning: only including urogenital sonography and punching
                                       #121.01 +                        # MRI guiding (NB: assumes a preceding MRI)
                                       9.54)                            # Pathology of biopsy

sum_cost_remaining_life_wMRI <- cost_per_year_first_year_wMRI + cost_per_year_second_year_wMRI + ((est_remaining_life-2)*yearly_recurring_cost_after_2_years_wMRI)

new_cost_with_MRI <-  sum_cost_remaining_life_wMRI/est_remaining_life

#=======================================================================================================================
# Calculate yearly post treatment follow up cost to use later in the function
#=======================================================================================================================

# S3 Guidelines: 
# In asymptomatic patients after curative therapy, the determination of the serum PSA value should be used for follow-up. 
# Imaging techniques should only be used if therapeutic measures are possible and/or symptoms exist.
# (OBS! Guidelines only recommend PSA assay and DR's visits during long term follow up)

annual_cost_first_year_ptx <- # Consultation
                              21.26*4*0.2 +                # Basic flat rate per insured person per quarter: EBM (26211 + EBM26212)/2 (OBs! 0.2 to account for multiple services)  
                              21.95*4 +                    # Additional flat rate oncology 
  
                              #PSA assessments
                              4.80*4 +                     # PSA sampling
                              20.81*4                      # PSA analysis

annual_cost_second_year_ptx <- annual_cost_first_year_ptx

annual_cost_third_year_ptx <- 21.26*2*0.2 +                # Basic flat rate per insured person per quarter: EBM (26211 + EBM26212)/2 (OBs! 0.2 to account for multiple services)  
                              21.95*2 +                    # Additional flat rate oncology 
                              4.80*2 +                     # PSA sampling
                              20.81*2                      # PSA analysis

annual_cost_fourth_year_ptx <- annual_cost_third_year_ptx

sum_cost_2nd_and_3rd_and_4th_year_ptx <-annual_cost_second_year_ptx + annual_cost_third_year_ptx + annual_cost_fourth_year_ptx

annual_cost_fifth_year_ptx <- 21.26*1*0.2 +                # Basic flat rate per insured person per quarter: EBM (26211 + EBM26212)/2 (OBs! 0.2 to account for multiple services)  
                              21.95*1 +                    # Additional flat rate oncology 
                              4.80*1 +                     # PSA sampling
                              20.81*1                      # PSA analysis

total_annual_cost_after_first_year_ptx <- ((est_remaining_life-1)*annual_cost_fifth_year_ptx) + sum_cost_2nd_and_3rd_and_4th_year_ptx

yearly_posttreat_cost_after_year_1 <-  total_annual_cost_after_first_year_ptx/est_remaining_life   

cat(paste("Active surveillance - yearly - with MRI =", new_cost_with_MRI, "\n",
          "Active surveillance - yearly - w/o MRI =", new_cost_without_MRI, "\n",
          "Post-Tx follow-up - yearly first =", annual_cost_first_year_ptx, "\n",
          "Post-Tx follow-up - yearly after =", yearly_posttreat_cost_after_year_1), "\n")

