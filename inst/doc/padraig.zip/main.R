## Simulations
library(prostata)
shuang = prostata:::ShuangParameters(2018) # Should we change to 2020?
base = modifyList(prostata:::EdnaParameters(shuang),
                  list(frailty=TRUE, # use a frailty for onset
                       ancestry=TRUE, # include ancestry variation for the frailty
                       grs_version=2,
                       grs_risk_threshold=0.075,
                       grs_p_threshold=0.5,
                       grs_variance = 0.68, # standard GRS variance
                       other_variance = 1.14, # other variance component
                       ## GRS screening starts from 50
                       start_screening=50,
                       stop_screening=70,
                       screening_interval=21 # that is, a single screen
                       ))
base$cost_parameters["Polygenic risk stratification"] = 50
cost_parameters <- c(
  "Formal PSA" = 31.22,                               # Cost for PSA test
  "Opportunistic PSA" = 31.22,                        # Cost for PSA test
  "Biopsy" = 653.63,      # Cost for biopsy (systematic/MRI targeted)
  "MRI" = 381.38,                   # Cost for mpMRI scan
  "Assessment" = 613.13,   # Cost for assessing suspected prostate cancer
  "Prostatectomy" = 11034.00,                       # Cost for prostatectomy surgery
  "Radiation therapy" = 7269.75,                    # Cost for radiation therapy
  "Active surveillance - yearly - with MRI" = 649.13,          # Yearly cost for active surveillance
  "Terminal illness" = 8305.88/2,      # Cost for terminal care
  "Palliative therapy - yearly" = 8305.88      # Cost for palliative care
)
## names(cost_parameters) %in% names(base$cost_parameters)
for (nm in names(cost_parameters))
    base$cost_parameters[nm] = cost_parameters[nm]
edna <- base
base$utility_estimates = shuang$utility_estimates # PORPUS-U

optimistic = modifyList(base, list(grs_variance = 0.68+1.14, other_variance=0))
optimistic$cost_parameters["Polygenic risk stratification"] = 0

nsim = 1e7
cores = 40
## no screening/testing
set.seed(12345)
sim1 <- callFhcrc(nsim, screen="noScreen", mc.cores=cores, parms=base)
## single screen
set.seed(12345)
sim2 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(start_screening=50)))
set.seed(12345)
sim3 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(start_screening=60)))
set.seed(12345)
sim4 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(start_screening=70, stop_screening=71)))
## four-yearly
set.seed(12345)
sim5 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(screening_interval=4)))
## two-yearly
set.seed(12345)
sim6 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(screening_interval=2)))

## "Optimistic" -- GRS
## Single screen from 50 at X% risk threshold
set.seed(12345)
sim7 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                  parms=optimistic)
## Four-yearly screening from 50 at X% risk threshold
set.seed(12345)
sim8 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(optimistic,list(screening_interval=4)))
## Two-yearly screening from 50 at X% risk threshold
set.seed(12345)
sim9 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(optimistic,list(screening_interval=2)))

## GRS with 50 pounds per GRS
## Single screen from 50 at X% risk threshold
set.seed(12345)
sim10 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                  parms=base)
## Four-yearly screening from 50 at 1% risk threshold
set.seed(12345)
sim11 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(base,list(screening_interval=4)))
## Two-yearly screening from 50 at 1% risk threshold
set.seed(12345)
sim12 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(base,list(screening_interval=2)))


sims <- list(sim1, sim2, sim3, sim4, sim5, sim6, sim7, sim8, sim9, sim10, sim11, sim12)

save(sims,file="~/Documents/clients/padraig/Docs/sims.RData")


base$utility_estimates = edna$utility_estimates # EQ-5D

optimistic = modifyList(base, list(grs_variance = 0.68+1.14, other_variance=0))
optimistic$cost_parameters["Polygenic risk stratification"] = 0

nsim = 1e7
cores = 40
## no screening/testing
set.seed(12345)
sim1 <- callFhcrc(nsim, screen="noScreen", mc.cores=cores, parms=base)
## single screen
set.seed(12345)
sim2 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(start_screening=50)))
set.seed(12345)
sim3 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(start_screening=60)))
set.seed(12345)
sim4 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(start_screening=70, stop_screening=71)))
## four-yearly
set.seed(12345)
sim5 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(screening_interval=4)))
## two-yearly
set.seed(12345)
sim6 <- callFhcrc(nsim, screen="regular_screen", mc.cores=cores,
                  parms=modifyList(base,list(screening_interval=2)))

## "Optimistic" -- GRS
## Single screen from 50 at X% risk threshold
set.seed(12345)
sim7 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                  parms=optimistic)
## Four-yearly screening from 50 at X% risk threshold
set.seed(12345)
sim8 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(optimistic,list(screening_interval=4)))
## Two-yearly screening from 50 at X% risk threshold
set.seed(12345)
sim9 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(optimistic,list(screening_interval=2)))

## GRS with 50 pounds per GRS
## Single screen from 50 at X% risk threshold
set.seed(12345)
sim10 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                  parms=base)
## Four-yearly screening from 50 at 1% risk threshold
set.seed(12345)
sim11 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(base,list(screening_interval=4)))
## Two-yearly screening from 50 at 1% risk threshold
set.seed(12345)
sim12 <- callFhcrc(nsim, screen="grs_stratified_p", mc.cores=cores,
                 parms=modifyList(base,list(screening_interval=2)))


sims <- list(sim1, sim2, sim3, sim4, sim5, sim6, sim7, sim8, sim9, sim10, sim11, sim12)

save(sims,file="~/Documents/clients/padraig/Docs/sims_eq5d.RData")

