#!/usr/bin/bash
#SBATCH -n 40
#SBATCH -t 36:00:00
#SBATCH --mem 300000
module load R
R -f main.R
