library(prostata)
library(dampack)
library(dplyr)
library(knitr)

Strategies = c("No screening", "50", "60", "70", "4-yearly", "2-yearly", "50 (PRS first, upper bound)",
               "4-yearly (PRS first, upper bound)", "2-yearly\n(PRS first, upper bound)", "50 (PRS first, pragmatic)",
               "4-yearly (PRS first, pragmatic)", "2-yearly (PRS first, pragmatic)")
load(file="~/Documents/clients/padraig/Docs/sims.RData")
sims = lapply(sims, summary, from=50) |>
    Reduce(function(x,agg) mapply(c, x, agg, SIMPLIFY=FALSE), x=_) |>
    as.data.frame() |>
    transform(Strategy=Strategies)
sims = with(sims, microsimulation::frontier(QALE, healthsector.costs, FALSE)) |>
    as.data.frame() |>
    transform(QALE=x,healthsector.costs=y,ICER=c(NA,diff(y)/diff(x))) |>
    merge(sims,all.y=TRUE) |> 
    transform(Label = ifelse(is.na(ICER),Strategy,sprintf("%s\nICER=£%.0f/QALY",Strategy,floor(ICER/100)*100)))
sims = sims[order(sims$healthsector.costs),]
sims$Label[2] = gsub("\n",", ",sims$Label[2])

pdf("~/Documents/clients/padraig/Docs/frontier.pdf",width=7*1.5,height=5*1.5)
with(sims, {
    xdiff = diff(range(QALE))
    plot(healthsector.costs~QALE, pch=19,
         xlim=range(QALE)+c(-0.15*xdiff,0.25*xdiff),
         ylim=range(healthsector.costs)+c(-25,25),
         xlab="Discounted quality-adjusted life expectancy from age 50",
         ylab="Discounted lifetime expected costs from age 50")
    pos = c(1,4,2,2,2,2,4,2,4,1,2,4)
    text(QALE, healthsector.costs, Label, pos=pos)
    with(microsimulation::frontier(QALE, healthsector.costs, FALSE),
         lines(x,y,lty=1))
    with(subset(sims, !grepl("upper",Strategy)),
         with(microsimulation::frontier(QALE, healthsector.costs, FALSE),
              lines(x,y,lty=2)))
    legend("topleft", legend=c("Frontier excluding upper bound strategies","Frontier for all strategies"),
           lty=2:1, bty="n")
}) 
dev.off()

unrestricted = with(sims,
     dampack::calculate_icers(cost=healthsector.costs,
                              effect = QALE,
                              strategies = Strategy))
index = with(sims,!grepl("upper",Strategy))
restricted = with(as.data.frame(sims)[index,],
    dampack::calculate_icers(cost=healthsector.costs,
                             effect = QALE,
                             strategies = Strategy))
options(width=140)

tab = unrestricted |>
    transform(id=1:length(ICER),Strategy=as.character(Strategy)) |>
    merge(transform(sims,ICER=NULL,Strategy=as.character(Strategy)), all.y=TRUE,by="Strategy") |>
    arrange(id) |>
    with(data.frame(
        Strategy,
        `Mean lifetime number of PSA tests`=screening.tests,
        `Mean lifetime number of biopsies`=biopsies,
        ## `Screen-initiated biopsies`=biopsies.screen.initiated,
        `Lifetime risk of a prostate cancer diagnosis`=diagnosis,
        `Lifetime risk of a prostate cancer death`=cancer.deaths,
        `Life expectancy`=LE,
        `Discounted societal costs`=societal.costs,
        `Discounted health-sector costs`=Cost,
        `Discounted quality-adjusted life expectancy`=Effect,
        `Incremental costs`=Inc_Cost,
        `Incremental effects`=Inc_Effect,
        ICER,
        Status,
        check.names=FALSE))
tab
kable(tab,"html") |> cat(file="../Docs/tab-unrestricted.html")

tab = restricted |>
    transform(id=1:length(ICER),Strategy=as.character(Strategy)) |>
    merge(transform(sims,ICER=NULL,Strategy=as.character(Strategy)), all.y=TRUE,by="Strategy") |>
    arrange(id) |>
    with(data.frame(
        Strategy,
        `Mean lifetime number of PSA tests`=screening.tests,
        `Mean lifetime number of biopsies`=biopsies,
        ## `Screen-initiated biopsies`=biopsies.screen.initiated,
        `Lifetime risk of a prostate cancer diagnosis`=diagnosis,
        `Lifetime risk of a prostate cancer death`=cancer.deaths,
        `Life expectancy`=LE,
        `Discounted societal costs`=societal.costs,
        `Discounted health-sector costs`=Cost,
        `Discounted quality-adjusted life expectancy`=Effect,
        `Incremental costs`=Inc_Cost,
        `Incremental effects`=Inc_Effect,
        ICER,
        Status,
        check.names=FALSE))
tab
kable(tab,"html") |> cat(file="../Docs/tab-restricted.html")


#######################################
## Same code for EQ-5D

load(file="~/Documents/clients/padraig/Docs/sims_eq5d.RData")
sims = lapply(sims, summary, from=50) |>
    Reduce(function(x,agg) mapply(c, x, agg, SIMPLIFY=FALSE), x=_) |>
    as.data.frame() |>
    transform(Strategy=Strategies)
sims = with(sims, microsimulation::frontier(QALE, healthsector.costs, FALSE)) |>
    as.data.frame() |>
    transform(QALE=x,healthsector.costs=y,ICER=c(NA,diff(y)/diff(x))) |>
    merge(sims,all.y=TRUE) |> 
    transform(Label = ifelse(is.na(ICER),Strategy,sprintf("%s\nICER=£%.0f/QALY",Strategy,floor(ICER/100)*100)))
sims = sims[order(sims$healthsector.costs),]
sims$Label[2] = gsub("\n",", ",sims$Label[2])

pdf("~/Documents/clients/padraig/Docs/frontier-eq5d.pdf",width=7*1.5,height=5*1.5)
with(sims, {
    xdiff = diff(range(QALE))
    plot(healthsector.costs~QALE, pch=19,
         xlim=range(QALE)+c(-0.15*xdiff,0.25*xdiff),
         ylim=range(healthsector.costs)+c(-25,25),
         xlab="Discounted quality-adjusted life expectancy from age 50",
         ylab="Discounted lifetime expected costs from age 50")
    pos = c(1,4,2,2,2,2,4,2,4,1,2,4)
    text(QALE, healthsector.costs, Label, pos=pos)
    with(microsimulation::frontier(QALE, healthsector.costs, FALSE),
         lines(x,y,lty=1))
    with(subset(sims, !grepl("upper",Strategy)),
         with(microsimulation::frontier(QALE, healthsector.costs, FALSE),
              lines(x,y,lty=2)))
    legend("topleft", legend=c("Frontier excluding upper bound strategies","Frontier for all strategies"),
           lty=2:1, bty="n")
}) 
dev.off()

unrestricted = with(sims,
     dampack::calculate_icers(cost=healthsector.costs,
                              effect = QALE,
                              strategies = Strategy))
index = with(sims,!grepl("upper",Strategy))
restricted = with(as.data.frame(sims)[index,],
    dampack::calculate_icers(cost=healthsector.costs,
                             effect = QALE,
                             strategies = Strategy))
options(width=140)

tab = unrestricted |>
    transform(id=1:length(ICER),Strategy=as.character(Strategy)) |>
    merge(transform(sims,ICER=NULL,Strategy=as.character(Strategy)), all.y=TRUE,by="Strategy") |>
    arrange(id) |>
    with(data.frame(
        Strategy,
        `Mean lifetime number of PSA tests`=screening.tests,
        `Mean lifetime number of biopsies`=biopsies,
        ## `Screen-initiated biopsies`=biopsies.screen.initiated,
        `Lifetime risk of a prostate cancer diagnosis`=diagnosis,
        `Lifetime risk of a prostate cancer death`=cancer.deaths,
        `Life expectancy`=LE,
        `Discounted societal costs`=societal.costs,
        `Discounted health-sector costs`=Cost,
        `Discounted quality-adjusted life expectancy`=Effect,
        `Incremental costs`=Inc_Cost,
        `Incremental effects`=Inc_Effect,
        ICER,
        Status,
        check.names=FALSE))
tab
kable(tab,"html") |> cat(file="../Docs/tab-unrestricted-eq5d.html")

tab = restricted |>
    transform(id=1:length(ICER),Strategy=as.character(Strategy)) |>
    merge(transform(sims,ICER=NULL,Strategy=as.character(Strategy)), all.y=TRUE,by="Strategy") |>
    arrange(id) |>
    with(data.frame(
        Strategy,
        `Mean lifetime number of PSA tests`=screening.tests,
        `Mean lifetime number of biopsies`=biopsies,
        ## `Screen-initiated biopsies`=biopsies.screen.initiated,
        `Lifetime risk of a prostate cancer diagnosis`=diagnosis,
        `Lifetime risk of a prostate cancer death`=cancer.deaths,
        `Life expectancy`=LE,
        `Discounted societal costs`=societal.costs,
        `Discounted health-sector costs`=Cost,
        `Discounted quality-adjusted life expectancy`=Effect,
        `Incremental costs`=Inc_Cost,
        `Incremental effects`=Inc_Effect,
        ICER,
        Status,
        check.names=FALSE))
tab
kable(tab,"html") |> cat(file="../Docs/tab-restricted-eq5d.html")


